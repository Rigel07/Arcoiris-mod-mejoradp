package com.treasurerainbow.client;

import com.treasurerainbow.ModRegistry;
import com.treasurerainbow.TreasureRainbowMod;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TreasureRainbowMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientEvents {

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModRegistry.RAINBOW.get(), RainbowRenderer::new);
        event.registerEntityRenderer(ModRegistry.LEPRECHAUN.get(), LeprechaunRenderer::new);
        event.registerEntityRenderer(ModRegistry.CRAZY_BIRD.get(), CrazyBirdRenderer::new);
        event.registerEntityRenderer(ModRegistry.ELF.get(), ElfRenderer::new);
        event.registerEntityRenderer(ModRegistry.SLEIGH.get(), SleighRenderer::new);
        event.registerEntityRenderer(ModRegistry.CUPID.get(), CupidRenderer::new);
        event.registerEntityRenderer(ModRegistry.HEART_ARROW.get(), HeartArrowRenderer::new);
    }

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(LeprechaunModel.LAYER, LeprechaunModel::createBodyLayer);
        event.registerLayerDefinition(CrazyBirdModel.LAYER, CrazyBirdModel::createBodyLayer);
        event.registerLayerDefinition(SleighModel.LAYER, SleighModel::createBodyLayer);
        event.registerLayerDefinition(CupidModel.LAYER, CupidModel::createBodyLayer);
        event.registerLayerDefinition(HaloLayer.LAYER, HaloLayer::createRing);
    }

    @SubscribeEvent
    public static void addPlayerLayers(EntityRenderersEvent.AddLayers event) {
        for (String skin : new String[]{"default", "slim"}) {
            PlayerRenderer renderer = event.getSkin(skin);
            if (renderer != null) {
                renderer.addLayer(new HaloLayer(renderer, event.getEntityModels()));
            }
        }
    }
}
