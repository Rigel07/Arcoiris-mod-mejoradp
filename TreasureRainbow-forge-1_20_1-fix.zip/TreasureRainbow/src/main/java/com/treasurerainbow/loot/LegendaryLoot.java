package com.treasurerainbow.loot;

import com.treasurerainbow.TreasureRainbowMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TieredItem;
import net.minecraftforge.common.Tags;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Botín "de todos los mods": recorre el registro de objetos (vanilla y de cualquier mod instalado)
 * y elige objetos valiosos o de otros mods al azar. Se calcula la primera vez que se necesita.
 */
public final class LegendaryLoot {
    private LegendaryLoot() {}

    /** Objetos vanilla que no deben salir nunca (solo creativo / rotos). */
    private static final Set<String> BLACKLIST = Set.of(
            "command_block", "chain_command_block", "repeating_command_block", "command_block_minecart",
            "structure_block", "structure_void", "jigsaw", "barrier", "light", "debug_stick", "knowledge_book",
            "bedrock", "spawner", "reinforced_deepslate", "petrified_oak_slab", "budding_amethyst");

    private static List<Item> valuable;
    private static List<Item> modded;

    private static synchronized void init() {
        if (valuable != null) {
            return;
        }
        List<Item> v = new ArrayList<>();
        List<Item> m = new ArrayList<>();
        for (Item item : ForgeRegistries.ITEMS) {
            try {
                ResourceLocation key = ForgeRegistries.ITEMS.getKey(item);
                if (key == null || item == Items.AIR) {
                    continue;
                }
                String ns = key.getNamespace();
                if (ns.equals("minecraft") && BLACKLIST.contains(key.getPath())) {
                    continue;
                }
                ItemStack stack = new ItemStack(item);
                if (isValuable(item, stack, ns)) {
                    v.add(item);
                }
                if (!ns.equals("minecraft") && !ns.equals(TreasureRainbowMod.MOD_ID)) {
                    m.add(item);
                }
            } catch (Throwable ignored) {
                // un objeto raro de otro mod no debe romper el botín
            }
        }
        modded = m;
        valuable = v;
    }

    private static boolean isValuable(Item item, ItemStack stack, String ns) {
        Rarity rarity = stack.getRarity();
        if (rarity == Rarity.RARE || rarity == Rarity.EPIC) {
            return true;
        }
        if (stack.is(Tags.Items.GEMS) || stack.is(Tags.Items.INGOTS_NETHERITE)) {
            return true;
        }
        if (!ns.equals("minecraft") && stack.is(Tags.Items.INGOTS)) {
            return true;
        }
        if (item instanceof TieredItem tiered && tiered.getTier().getLevel() >= 3) {
            return true;
        }
        return item instanceof ArmorItem armor && armor.getMaterial().getToughness() >= 2.0F;
    }

    /** Un objeto valioso al azar (vanilla o de cualquier mod). */
    public static ItemStack randomValuable(RandomSource random) {
        init();
        return pick(valuable, random);
    }

    /** Un objeto al azar de los mods instalados (vacío si solo hay vanilla). */
    public static ItemStack randomModded(RandomSource random) {
        init();
        return pick(modded, random);
    }

    private static ItemStack pick(List<Item> list, RandomSource random) {
        if (list == null || list.isEmpty()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = new ItemStack(list.get(random.nextInt(list.size())));
        int max = stack.getMaxStackSize();
        if (max > 1 && !stack.isDamageableItem()) {
            stack.setCount(1 + random.nextInt(Math.min(max, 6)));
        }
        return stack;
    }
}
