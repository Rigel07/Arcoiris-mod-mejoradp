package com.treasurerainbow;

import com.treasurerainbow.entity.LeprechaunEntity;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Eventos del bus del mod (atributos de las entidades). */
@Mod.EventBusSubscriber(modid = TreasureRainbowMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModRegistry.LEPRECHAUN.get(), LeprechaunEntity.createAttributes().build());
    }
}
