package com.treasurerainbow.block;

import com.treasurerainbow.ModRegistry;
import com.treasurerainbow.loot.LegendaryLoot;
import com.treasurerainbow.world.SaintJohnNight;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.ArrayList;
import java.util.List;

/**
 * Hoguera de San Juan. Se puede cruzar (saltarla purifica, sin hacer daño), quema a los no-muertos
 * que se acercan y cura a los jugadores cercanos. Rituales (clic derecho):
 * hierba de San Juan = purificación; papel = deseo (solo la Noche de San Juan).
 * Las hogueras "naturales" que aparecen durante la noche se apagan al amanecer.
 */
public class SanJuanBonfireBlock extends Block {
    public static final BooleanProperty NATURAL = BooleanProperty.create("natural");
    private static final VoxelShape SHAPE = Block.box(1.0D, 0.0D, 1.0D, 15.0D, 12.0D, 15.0D);
    private static final String PURIFY_KEY = "treasure_rainbow_purify_tick";
    private static final String JUMP_NIGHT_KEY = "treasure_rainbow_jump_night";
    private static final String JUMP_COUNT_KEY = "treasure_rainbow_jump_count";
    private static final int AURA_RADIUS = 6;

    public SanJuanBonfireBlock(Properties properties) {
        super(properties);
        registerDefaultState(this.stateDefinition.any().setValue(NATURAL, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(NATURAL);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean isMoving) {
        if (!level.isClientSide) {
            level.scheduleTick(pos, this, 20);
        }
    }

    // ------------------------------------------------------------ Saltar el fuego

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (level.isClientSide) {
            return;
        }
        if (entity instanceof ServerPlayer player) {
            if (!player.isSpectator() && level.getGameTime() - player.getPersistentData().getLong(PURIFY_KEY) >= 100L) {
                player.getPersistentData().putLong(PURIFY_KEY, level.getGameTime());
                purify(player);
                player.displayClientMessage(Component.translatable("message.treasure_rainbow.purified"), true);
                countJump(player, (ServerLevel) level);
            }
        } else if (entity instanceof LivingEntity living && living.isInvertedHealAndHarm()) {
            living.setSecondsOnFire(6);
        }
    }

    /** Tradición: saltar la hoguera tres veces la Noche de San Juan trae suerte para todo el año. */
    private static void countJump(ServerPlayer player, ServerLevel level) {
        if (!SaintJohnNight.isActive(level)) {
            return;
        }
        CompoundTag tag = player.getPersistentData();
        long night = SaintJohnNight.currentStartDay(level);
        if (tag.getLong(JUMP_NIGHT_KEY) != night + 1L) {
            tag.putLong(JUMP_NIGHT_KEY, night + 1L);
            tag.putInt(JUMP_COUNT_KEY, 0);
        }
        int jumps = tag.getInt(JUMP_COUNT_KEY) + 1;
        tag.putInt(JUMP_COUNT_KEY, jumps);
        if (jumps == 3) {
            player.addEffect(new MobEffectInstance(MobEffects.LUCK, 6000, 1));
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 3600, 0));
            ExperienceOrb.award(level, player.position(), 40);
            level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, player.getX(), player.getY() + 1.0D, player.getZ(),
                    30, 0.4D, 0.7D, 0.4D, 0.3D);
            player.displayClientMessage(Component.translatable("message.treasure_rainbow.three_jumps"), true);
        }
    }

    /** Quita todos los efectos negativos y el fuego, sin dañar. */
    public static void purify(LivingEntity entity) {
        List<net.minecraft.world.effect.MobEffect> bad = new ArrayList<>();
        for (MobEffectInstance instance : entity.getActiveEffects()) {
            if (instance.getEffect().getCategory() == MobEffectCategory.HARMFUL) {
                bad.add(instance.getEffect());
            }
        }
        for (net.minecraft.world.effect.MobEffect effect : bad) {
            entity.removeEffect(effect);
        }
        entity.clearFire();
        if (entity.level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.HAPPY_VILLAGER, entity.getX(), entity.getY() + 1.0D, entity.getZ(),
                    12, 0.4D, 0.6D, 0.4D, 0.02D);
        }
    }

    // ---------------------------------------------------------------- Rituales

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand,
                                 BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);
        boolean herb = held.is(ModRegistry.ST_JOHNS_WORT_ITEM.get());
        boolean paper = held.is(Items.PAPER);
        boolean bottle = held.is(Items.GLASS_BOTTLE);
        if (!herb && !paper && !bottle) {
            return InteractionResult.PASS;
        }
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        ServerLevel serverLevel = (ServerLevel) level;
        boolean event = SaintJohnNight.isActive(serverLevel);

        if (bottle) {
            if (!event) {
                player.displayClientMessage(Component.translatable("message.treasure_rainbow.bottle_no_event"), true);
                return InteractionResult.CONSUME;
            }
            if (!player.getAbilities().instabuild) {
                held.shrink(1);
            }
            ItemStack water = new ItemStack(ModRegistry.SAN_JUAN_WATER.get());
            if (!player.getInventory().add(water)) {
                player.drop(water, false);
            }
            serverLevel.playSound(null, pos, SoundEvents.BOTTLE_FILL, SoundSource.BLOCKS, 1.0F, 1.0F);
            player.displayClientMessage(Component.translatable("message.treasure_rainbow.bottle_filled"), true);
            return InteractionResult.CONSUME;
        }

        if (herb) {
            if (!player.getAbilities().instabuild) {
                held.shrink(1);
            }
            for (Player near : serverLevel.getEntitiesOfClass(Player.class, new AABB(pos).inflate(8.0D))) {
                purify(near);
                near.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 300, 1));
                if (event) {
                    near.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 3600, 0));
                }
            }
            serverLevel.sendParticles(ParticleTypes.FLAME, pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D,
                    40, 0.4D, 0.6D, 0.4D, 0.06D);
            serverLevel.playSound(null, pos, SoundEvents.FIRECHARGE_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
            player.displayClientMessage(Component.translatable("message.treasure_rainbow.ritual_herb"), true);
            return InteractionResult.CONSUME;
        }

        // Papel: un deseo que se quema. Solo la Noche de San Juan.
        if (!event) {
            player.displayClientMessage(Component.translatable("message.treasure_rainbow.wish_no_event"), true);
            return InteractionResult.CONSUME;
        }
        if (!player.getAbilities().instabuild) {
            held.shrink(1);
        }
        RandomSource random = serverLevel.random;
        double roll = random.nextDouble();
        Vec3 center = Vec3.atCenterOf(pos).add(0.0D, 0.8D, 0.0D);
        if (roll < 0.5D) {
            ExperienceOrb.award(serverLevel, center, 30 + random.nextInt(30));
            player.addEffect(new MobEffectInstance(MobEffects.LUCK, 3600, 0));
            player.displayClientMessage(Component.translatable("message.treasure_rainbow.wish_xp"), true);
        } else if (roll < 0.8D) {
            Block.popResource(serverLevel, pos.above(), new ItemStack(ModRegistry.FOUR_LEAF_CLOVER_ITEM.get(), 1 + random.nextInt(3)));
            player.displayClientMessage(Component.translatable("message.treasure_rainbow.wish_clover"), true);
        } else {
            ItemStack reward = LegendaryLoot.randomValuable(random);
            if (reward.isEmpty()) {
                reward = new ItemStack(ModRegistry.FOUR_LEAF_CLOVER_ITEM.get(), 2);
            }
            Block.popResource(serverLevel, pos.above(), reward);
            player.displayClientMessage(Component.translatable("message.treasure_rainbow.wish_treasure"), true);
        }
        serverLevel.sendParticles(ParticleTypes.FLAME, center.x, center.y, center.z, 30, 0.3D, 0.5D, 0.3D, 0.08D);
        serverLevel.playSound(null, pos, SoundEvents.FIRECHARGE_USE, SoundSource.BLOCKS, 1.0F, 1.3F);
        return InteractionResult.CONSUME;
    }

    // ------------------------------------------------------- Aura y amanecer

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        boolean event = SaintJohnNight.isActive(level);
        if (state.getValue(NATURAL) && !event) {
            level.sendParticles(ParticleTypes.LARGE_SMOKE, pos.getX() + 0.5D, pos.getY() + 0.8D, pos.getZ() + 0.5D,
                    12, 0.3D, 0.4D, 0.3D, 0.03D);
            level.removeBlock(pos, false);
            return;
        }
        for (LivingEntity living : level.getEntitiesOfClass(LivingEntity.class, new AABB(pos).inflate(AURA_RADIUS))) {
            if (living instanceof Player player) {
                if (!player.isSpectator()) {
                    player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 80, 0, true, false, false));
                }
            } else if (living.isInvertedHealAndHarm()) {
                living.setSecondsOnFire(4);
            }
        }
        if (event && state.getValue(NATURAL) && random.nextInt(8) == 0) {
            launchFirework(level, pos, random);
        }
        level.scheduleTick(pos, this, 20);
    }

    private static void launchFirework(ServerLevel level, BlockPos pos, RandomSource random) {
        int[] palette = {0xFF4500, 0xFFD700, 0xFF69B4, 0x00BFFF, 0x7CFC00};
        ItemStack rocket = new ItemStack(Items.FIREWORK_ROCKET);
        CompoundTag fireworks = rocket.getOrCreateTagElement("Fireworks");
        fireworks.putByte("Flight", (byte) 1);
        ListTag explosions = new ListTag();
        CompoundTag explosion = new CompoundTag();
        explosion.putByte("Type", (byte) random.nextInt(2));
        explosion.putIntArray("Colors", new int[]{palette[random.nextInt(palette.length)], palette[random.nextInt(palette.length)]});
        explosions.add(explosion);
        fireworks.put("Explosions", explosions);
        level.addFreshEntity(new FireworkRocketEntity(level, pos.getX() + 0.5D, pos.getY() + 1.2D, pos.getZ() + 0.5D, rocket));
    }

    // -------------------------------------------------------------- Ambiente

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(6) == 0) {
            level.playLocalSound(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D,
                    SoundEvents.CAMPFIRE_CRACKLE, SoundSource.BLOCKS, 0.8F, 0.9F + random.nextFloat() * 0.3F, false);
        }
        for (int i = 0; i < 2; i++) {
            level.addParticle(ParticleTypes.FLAME,
                    pos.getX() + 0.25D + random.nextDouble() * 0.5D, pos.getY() + 0.8D + random.nextDouble() * 0.5D,
                    pos.getZ() + 0.25D + random.nextDouble() * 0.5D, 0.0D, 0.04D, 0.0D);
        }
        if (random.nextInt(4) == 0) {
            level.addParticle(ParticleTypes.LAVA, pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D, 0.0D, 0.0D, 0.0D);
        }
        if (random.nextInt(3) == 0) {
            level.addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE, pos.getX() + 0.5D, pos.getY() + 1.3D, pos.getZ() + 0.5D,
                    0.0D, 0.06D, 0.0D);
        }
    }
}
