package com.treasurerainbow.block;

import com.treasurerainbow.ModRegistry;
import com.treasurerainbow.loot.LegendaryLoot;
import com.treasurerainbow.world.RainbowSpawner;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Cofre de 27 huecos cuyo botín (loot table) se genera al abrirlo por primera vez. */
public class RainbowChestBlockEntity extends RandomizableContainerBlockEntity {
    private NonNullList<ItemStack> items = NonNullList.withSize(27, ItemStack.EMPTY);
    /** Si es true, al abrirlo por primera vez se añaden además objetos de todos los mods instalados. */
    private boolean modLoot;

    public RainbowChestBlockEntity(BlockPos pos, BlockState state) {
        super(ModRegistry.RAINBOW_CHEST_BE.get(), pos, state);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        if (!this.trySaveLootTable(tag)) {
            ContainerHelper.saveAllItems(tag, this.items);
        }
        tag.putBoolean("ModLoot", this.modLoot);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.items = NonNullList.withSize(getContainerSize(), ItemStack.EMPTY);
        if (!this.tryLoadLootTable(tag)) {
            ContainerHelper.loadAllItems(tag, this.items);
        }
        this.modLoot = tag.getBoolean("ModLoot");
    }

    /** Marca el cofre como "legendario": además de su loot table lleva objetos de otros mods. */
    public void setModLoot(boolean modLoot) {
        this.modLoot = modLoot;
        setChanged();
    }

    @Override
    public int getContainerSize() {
        return 27;
    }

    @Override
    protected NonNullList<ItemStack> getItems() {
        return this.items;
    }

    @Override
    protected void setItems(NonNullList<ItemStack> list) {
        this.items = list;
    }

    @Override
    protected Component getDefaultName() {
        return Component.translatable("container.treasure_rainbow.rainbow_chest");
    }

    @Override
    protected AbstractContainerMenu createMenu(int id, Inventory inventory) {
        return ChestMenu.threeRows(id, inventory, this);
    }

    /** true mientras nadie ha abierto el cofre (el botín aún no se ha generado). */
    public boolean hasUnclaimedLoot() {
        return this.lootTable != null;
    }

    /** Quita el botín sin generarlo (para retirar un cofre que nadie reclamó). */
    public void discardLoot() {
        this.lootTable = null;
        setChanged();
    }

    @Override
    public void unpackLootTable(@Nullable Player player) {
        boolean unclaimed = this.lootTable != null;
        super.unpackLootTable(player);
        if (unclaimed && this.level instanceof ServerLevel serverLevel) {
            if (this.modLoot) {
                this.modLoot = false;
                addModLoot(serverLevel.random);
            }
            RainbowSpawner.onTreasureClaimed(serverLevel, this.worldPosition);
        }
    }

    /** Rellena huecos libres con objetos valiosos y objetos de cualquier mod instalado. */
    private void addModLoot(RandomSource random) {
        List<Integer> empty = new ArrayList<>();
        for (int i = 0; i < this.items.size(); i++) {
            if (this.items.get(i).isEmpty()) {
                empty.add(i);
            }
        }
        Collections.shuffle(empty, new java.util.Random(random.nextLong()));
        int valuable = 3 + random.nextInt(3);
        int modded = 4 + random.nextInt(3);
        int next = 0;
        for (int i = 0; i < valuable + modded && next < empty.size(); i++) {
            ItemStack stack = i < valuable ? LegendaryLoot.randomValuable(random) : LegendaryLoot.randomModded(random);
            if (stack.isEmpty()) {
                continue;
            }
            this.items.set(empty.get(next++), stack);
        }
        setChanged();
    }
}
