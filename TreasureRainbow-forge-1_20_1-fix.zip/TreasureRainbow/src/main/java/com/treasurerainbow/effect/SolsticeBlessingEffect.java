package com.treasurerainbow.effect;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/** Efecto "Bendición del Solsticio": marca visible de la Noche de San Juan (lo gestiona SaintJohnNight). */
public class SolsticeBlessingEffect extends MobEffect {
    public SolsticeBlessingEffect() {
        super(MobEffectCategory.BENEFICIAL, 0xFF8C14);
    }
}
