package com.treasurerainbow.entity;

import com.treasurerainbow.ModRegistry;
import com.treasurerainbow.loot.LegendaryLoot;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.InteractGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.LookAtTradingPlayerGoal;
import net.minecraft.world.entity.ai.goal.MoveTowardsRestrictionGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.TradeWithPlayerGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

/**
 * San Patricio, el duende. Comercia con tréboles de cuatro hojas.
 * Si se le ha puesto un tiempo de vida, se esfuma en una nube de destellos cuando se acaba
 * (nunca mientras alguien comercia con él).
 */
public class LeprechaunEntity extends AbstractVillager {
    /** Ticks que le quedan; -1 = se queda para siempre. */
    private int despawnDelay = -1;

    public LeprechaunEntity(EntityType<? extends LeprechaunEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.5D)
                .add(Attributes.FOLLOW_RANGE, 16.0D);
    }

    public void setDespawnDelay(int ticks) {
        this.despawnDelay = ticks;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new TradeWithPlayerGoal(this));
        this.goalSelector.addGoal(1, new AvoidEntityGoal<>(this, Zombie.class, 8.0F, 0.5D, 0.5D));
        this.goalSelector.addGoal(1, new PanicGoal(this, 0.55D));
        this.goalSelector.addGoal(2, new LookAtTradingPlayerGoal(this));
        this.goalSelector.addGoal(4, new MoveTowardsRestrictionGoal(this, 0.35D));
        this.goalSelector.addGoal(8, new WaterAvoidingRandomStrollGoal(this, 0.35D));
        this.goalSelector.addGoal(9, new InteractGoal(this, Player.class, 3.0F, 1.0F));
        this.goalSelector.addGoal(10, new LookAtPlayerGoal(this, Mob.class, 8.0F));
    }

    // ---------------------------------------------------------------- Comercio

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (!held.is(Items.VILLAGER_SPAWN_EGG) && this.isAlive() && !this.isTrading() && !this.isBaby()) {
            if (hand == InteractionHand.MAIN_HAND) {
                player.awardStat(Stats.TALKED_TO_VILLAGER);
            }
            if (this.getOffers().isEmpty()) {
                return InteractionResult.sidedSuccess(this.level().isClientSide);
            }
            if (!this.level().isClientSide) {
                this.setTradingPlayer(player);
                this.openTradingScreen(player, this.getDisplayName(), 1);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    protected void updateTrades() {
        MerchantOffers offers = this.getOffers();
        add(offers, 1, new ItemStack(Items.GOLD_INGOT, 6), 16);
        add(offers, 1, new ItemStack(Items.EXPERIENCE_BOTTLE, 6), 12);
        add(offers, 2, new ItemStack(Items.EMERALD, 12), 12);
        add(offers, 3, new ItemStack(Items.DIAMOND, 2), 8);
        add(offers, 4, PotionUtils.setPotion(new ItemStack(Items.POTION), Potions.LUCK), 6);
        add(offers, 4, new ItemStack(ModRegistry.RAINBOW_DUST.get(), 6), 8);
        add(offers, 5, new ItemStack(Items.GOLDEN_APPLE, 2), 6);
        add(offers, 6, new ItemStack(ModRegistry.RAINBOW_GEM.get()), 4);
        add(offers, 8, new ItemStack(Items.TOTEM_OF_UNDYING), 3);
        add(offers, 10, new ItemStack(Items.ENCHANTED_GOLDEN_APPLE), 3);
        add(offers, 12, EnchantedBookItem.createForEnchantment(new EnchantmentInstance(Enchantments.MENDING, 1)), 2);
        add(offers, 14, new ItemStack(Items.NETHERITE_INGOT), 2);
        add(offers, 18, new ItemStack(Items.ELYTRA), 1);

        // Objetos misteriosos de otros mods (se eligen al aparecer el duende).
        ItemStack modded = LegendaryLoot.randomModded(this.random);
        if (!modded.isEmpty()) {
            add(offers, 8, modded, 2);
        }
        ItemStack valuable = LegendaryLoot.randomValuable(this.random);
        if (!valuable.isEmpty()) {
            add(offers, 12, valuable, 1);
        }
    }

    private static void add(MerchantOffers offers, int cloverCost, ItemStack result, int maxUses) {
        offers.add(new MerchantOffer(new ItemStack(ModRegistry.FOUR_LEAF_CLOVER_ITEM.get(), cloverCost),
                result, maxUses, 5, 0.0F));
    }

    @Override
    protected void rewardTradeXp(MerchantOffer offer) {
        if (offer.shouldRewardExp()) {
            int xp = 3 + this.random.nextInt(4);
            this.level().addFreshEntity(new ExperienceOrb(this.level(), this.getX(), this.getY() + 0.5D, this.getZ(), xp));
        }
    }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob mate) {
        return null;
    }

    // ------------------------------------------------------------ Vida y magia

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            if (this.random.nextInt(6) == 0) {
                this.level().addParticle(ParticleTypes.HAPPY_VILLAGER,
                        this.getX() + (this.random.nextDouble() - 0.5D) * 0.8D,
                        this.getY() + 0.4D + this.random.nextDouble() * 1.2D,
                        this.getZ() + (this.random.nextDouble() - 0.5D) * 0.8D,
                        0.0D, 0.02D, 0.0D);
            }
            return;
        }
        if (this.despawnDelay > 0 && !this.isTrading()) {
            this.despawnDelay--;
            if (this.despawnDelay == 0) {
                vanish();
            }
        }
    }

    private void vanish() {
        if (this.level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, this.getX(), this.getY() + 1.0D, this.getZ(),
                    30, 0.4D, 0.7D, 0.4D, 0.3D);
            serverLevel.playSound(null, this.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.NEUTRAL, 1.0F, 0.8F);
        }
        this.discard();
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return this.isTrading() ? SoundEvents.VILLAGER_TRADE : SoundEvents.VILLAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.VILLAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.VILLAGER_DEATH;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("DespawnDelay", this.despawnDelay);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.despawnDelay = tag.contains("DespawnDelay") ? tag.getInt("DespawnDelay") : -1;
    }
}
