package com.treasurerainbow.world;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** Estado guardado de la Noche de San Juan (vive en el Overworld). */
public class SaintJohnData extends SavedData {
    private static final String NAME = "treasure_rainbow_saint_john";

    public boolean active;
    /** Día del mundo en el que empezó la noche en curso. */
    public long startDay = -1L;
    /** Último día en el que ya se celebró (para no repetirla la misma noche). */
    public long lastStartedDay = -1L;

    public static SaintJohnData get(ServerLevel overworld) {
        return overworld.getDataStorage().computeIfAbsent(SaintJohnData::load, SaintJohnData::new, NAME);
    }

    public static SaintJohnData load(CompoundTag tag) {
        SaintJohnData data = new SaintJohnData();
        data.active = tag.getBoolean("Active");
        data.startDay = tag.contains("StartDay") ? tag.getLong("StartDay") : -1L;
        data.lastStartedDay = tag.contains("LastStartedDay") ? tag.getLong("LastStartedDay") : -1L;
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("Active", this.active);
        tag.putLong("StartDay", this.startDay);
        tag.putLong("LastStartedDay", this.lastStartedDay);
        return tag;
    }
}
