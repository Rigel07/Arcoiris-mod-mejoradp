package com.treasurerainbow.world;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** Estado guardado del evento "Día de San Patricio" (vive en el Overworld). */
public class SaintPatrickData extends SavedData {
    private static final String NAME = "treasure_rainbow_saint_patrick";

    /** Último día (número de día del mundo) que se ha comprobado; -1 = aún no. */
    public long lastDay = -1L;
    /** ¿Hay evento ahora mismo? */
    public boolean active;
    /** Número de evento: sube con cada evento nuevo para dar el escudo una sola vez por evento. */
    public int eventId;

    public static SaintPatrickData get(ServerLevel overworld) {
        return overworld.getDataStorage().computeIfAbsent(SaintPatrickData::load, SaintPatrickData::new, NAME);
    }

    public static SaintPatrickData load(CompoundTag tag) {
        SaintPatrickData data = new SaintPatrickData();
        data.lastDay = tag.contains("LastDay") ? tag.getLong("LastDay") : -1L;
        data.active = tag.getBoolean("Active");
        data.eventId = tag.getInt("EventId");
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putLong("LastDay", this.lastDay);
        tag.putBoolean("Active", this.active);
        tag.putInt("EventId", this.eventId);
        return tag;
    }
}
