package com.treasurerainbow.world;

import com.treasurerainbow.ModRegistry;
import com.treasurerainbow.TreasureRainbowMod;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

/**
 * El evento "Día de San Patricio".
 * <ul>
 *   <li>Al amanecer hay una probabilidad pequeña de que empiece; dura hasta el siguiente amanecer.</li>
 *   <li>Durante el evento todos los jugadores tienen el efecto Día de San Patricio (suerte, respiración
 *       acuática, inmunidad al fuego) y 5 corazones extra de escudo (absorción) que no quitan vida.</li>
 *   <li>Si el escudo se gasta, al comer se regenera (solo mientras dura el evento).</li>
 *   <li>Al acabar el evento el escudo y los efectos desaparecen.</li>
 * </ul>
 */
@Mod.EventBusSubscriber(modid = TreasureRainbowMod.MOD_ID)
public final class SaintPatrickDay {
    private SaintPatrickDay() {}

    /** Probabilidad de que empiece el evento en cada amanecer. */
    public static final double START_CHANCE = 0.06D;
    /** Escudo: 10 puntos = 5 corazones extra. */
    public static final float SHIELD = 10.0F;

    private static final String SHIELD_KEY = "treasure_rainbow_shield_event";
    /** Duración con la que se renuevan los efectos (ticks); se renuevan cada segundo. */
    private static final int EFFECT_TICKS = 240;

    public static boolean isActive(MinecraftServer server) {
        return server != null && SaintPatrickData.get(server.overworld()).active;
    }

    public static boolean isActive(ServerLevel level) {
        return isActive(level.getServer());
    }

    // ----------------------------------------------------------- Empezar / parar

    public static boolean start(MinecraftServer server) {
        SaintPatrickData data = SaintPatrickData.get(server.overworld());
        if (data.active) {
            return false;
        }
        data.active = true;
        data.eventId++;
        data.setDirty();
        Component title = Component.translatable("message.treasure_rainbow.saint_start.title");
        Component subtitle = Component.translatable("message.treasure_rainbow.saint_start.subtitle");
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.connection.send(new ClientboundSetTitlesAnimationPacket(10, 80, 30));
            player.connection.send(new ClientboundSetSubtitleTextPacket(subtitle));
            player.connection.send(new ClientboundSetTitleTextPacket(title));
            player.playNotifySound(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.PLAYERS, 1.0F, 1.0F);
            applyTo(player, data);
        }
        server.getPlayerList().broadcastSystemMessage(Component.translatable("message.treasure_rainbow.saint_start.chat"), false);
        return true;
    }

    public static boolean stop(MinecraftServer server) {
        SaintPatrickData data = SaintPatrickData.get(server.overworld());
        if (!data.active) {
            return false;
        }
        data.active = false;
        data.setDirty();
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            clearFrom(player);
        }
        server.getPlayerList().broadcastSystemMessage(Component.translatable("message.treasure_rainbow.saint_end"), false);
        return true;
    }

    // ------------------------------------------------------------------ Eventos

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null || server.getTickCount() % 20 != 0) {
            return;
        }
        ServerLevel overworld = server.overworld();
        SaintPatrickData data = SaintPatrickData.get(overworld);
        long day = overworld.getDayTime() / 24000L;

        if (data.lastDay < 0L) {
            data.lastDay = day;
            data.setDirty();
        } else if (day != data.lastDay) {
            data.lastDay = day;
            data.setDirty();
            if (data.active) {
                stop(server);
            } else if (overworld.random.nextDouble() < START_CHANCE) {
                start(server);
            }
        }

        if (data.active) {
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                applyTo(player, data);
            }
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && !isActive(player.getServer())) {
            clearFrom(player);
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            // Una vida nueva vuelve a recibir el escudo si el evento sigue en marcha.
            player.getPersistentData().remove(SHIELD_KEY);
        }
    }

    /** Comer regenera el escudo de corazones durante el evento. */
    @SubscribeEvent
    public static void onEat(LivingEntityUseItemEvent.Finish event) {
        if (event.getEntity() instanceof ServerPlayer player && event.getItem().isEdible()
                && isActive(player.getServer())) {
            if (player.getAbsorptionAmount() < SHIELD) {
                player.setAbsorptionAmount(SHIELD);
                player.level().playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME,
                        SoundSource.PLAYERS, 0.8F, 1.5F);
            }
        }
    }

    // ------------------------------------------------------------------ Ayudas

    private static void applyTo(ServerPlayer player, SaintPatrickData data) {
        if (player.isSpectator() || !player.isAlive()) {
            return;
        }
        refresh(player, ModRegistry.SAINT_PATRICK.get(), true);
        refresh(player, MobEffects.LUCK, false);
        refresh(player, MobEffects.WATER_BREATHING, false);
        refresh(player, MobEffects.FIRE_RESISTANCE, false);

        CompoundTag tag = player.getPersistentData();
        if (tag.getInt(SHIELD_KEY) != data.eventId) {
            tag.putInt(SHIELD_KEY, data.eventId);
            player.setAbsorptionAmount(SHIELD);
        }
    }

    private static void refresh(ServerPlayer player, MobEffect effect, boolean showIcon) {
        MobEffectInstance current = player.getEffect(effect);
        if (current == null || current.getDuration() < 100) {
            player.addEffect(new MobEffectInstance(effect, EFFECT_TICKS, 0, false, false, showIcon));
        }
    }

    private static void clearFrom(ServerPlayer player) {
        CompoundTag tag = player.getPersistentData();
        if (tag.contains(SHIELD_KEY)) {
            tag.remove(SHIELD_KEY);
            player.setAbsorptionAmount(0.0F);
        }
        removeOurs(player, ModRegistry.SAINT_PATRICK.get());
        removeOurs(player, MobEffects.LUCK);
        removeOurs(player, MobEffects.WATER_BREATHING);
        removeOurs(player, MobEffects.FIRE_RESISTANCE);
    }

    /** Solo quita el efecto si es el nuestro (corto); un efecto largo de una poción se respeta. */
    private static void removeOurs(ServerPlayer player, MobEffect effect) {
        MobEffectInstance current = player.getEffect(effect);
        if (current != null && current.getDuration() <= EFFECT_TICKS) {
            player.removeEffect(effect);
        }
    }
}
