package com.treasurerainbow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.treasurerainbow.TreasureRainbowMod;
import com.treasurerainbow.entity.GuizerEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class GuizerRenderer extends MobRenderer<GuizerEntity, GuizerModel<GuizerEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(TreasureRainbowMod.MOD_ID, "textures/entity/guizer.png");

    public GuizerRenderer(EntityRendererProvider.Context context) {
        super(context, new GuizerModel<>(context.bakeLayer(GuizerModel.LAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(GuizerEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(GuizerEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.0F, 1.0F, 1.0F);
    }
}
