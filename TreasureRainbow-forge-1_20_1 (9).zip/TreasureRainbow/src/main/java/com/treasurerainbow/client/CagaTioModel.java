package com.treasurerainbow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.treasurerainbow.TreasureRainbowMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/** Modelo generado: CagaTioModel. */
public class CagaTioModel<T extends Entity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(TreasureRainbowMod.MOD_ID, "caga_tio"), "main");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart rest;
    private final ModelPart blanket;
    private final ModelPart cap;
    private final ModelPart cap_tail;
    private final ModelPart leg_l;
    private final ModelPart leg_r;

    public CagaTioModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.rest = root.getChild("rest");
        this.blanket = root.getChild("blanket");
        this.cap = root.getChild("cap");
        this.cap_tail = root.getChild("cap_tail");
        this.leg_l = root.getChild("leg_l");
        this.leg_r = root.getChild("leg_r");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-3.5F, -3.5F, -7F, 7F, 7F, 14F), PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, 0F));
        PartDefinition p_rest = root.addOrReplaceChild("rest", CubeListBuilder.create().texOffs(0, 21).addBox(-2.5F, 0F, -1.5F, 5F, 4F, 3F), PartPose.offsetAndRotation(0F, 20F, 6.5F, 0F, 0F, 0F));
        PartDefinition p_blanket = root.addOrReplaceChild("blanket", CubeListBuilder.create().texOffs(42, 0).addBox(-4F, -4.5F, -2F, 8F, 5F, 9F), PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, 0F));
        PartDefinition p_cap = root.addOrReplaceChild("cap", CubeListBuilder.create().texOffs(76, 0).addBox(-3F, -6.5F, -7F, 6F, 3F, 6F), PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, 0F));
        PartDefinition p_cap_tail = root.addOrReplaceChild("cap_tail", CubeListBuilder.create().texOffs(100, 0).addBox(2.5F, -6.5F, -6F, 3F, 5F, 3F), PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, 0.2F));
        PartDefinition p_leg_l = root.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(112, 0).addBox(-1F, 0F, -1F, 2F, 5F, 2F), PartPose.offsetAndRotation(2.5F, 19F, -5F, 0F, 0F, 0F));
        PartDefinition p_leg_r = root.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(112, 0).addBox(-1F, 0F, -1F, 2F, 5F, 2F), PartPose.offsetAndRotation(-2.5F, 19F, -5F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 128, 64);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.leg_l.xRot = Mth.cos(limbSwing * 0.6662F) * 0.8F * limbSwingAmount;
        this.leg_r.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 0.8F * limbSwingAmount;
        this.cap_tail.zRot = 0.2F + Mth.sin(ageInTicks * 0.08F) * 0.05F;
        this.body.yRot = netHeadYaw * Mth.DEG_TO_RAD * 0.3F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
