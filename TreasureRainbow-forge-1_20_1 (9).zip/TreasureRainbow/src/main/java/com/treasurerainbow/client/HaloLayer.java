package com.treasurerainbow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.treasurerainbow.TreasureRainbowMod;
import com.treasurerainbow.halo.ClientHaloCache;
import com.treasurerainbow.item.AngelHaloItem;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Dibuja el Halo Angelical (un anillo dorado) flotando sobre la cabeza del jugador. */
public class HaloLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(TreasureRainbowMod.MOD_ID, "halo"), "main");
    private static final ResourceLocation TEXTURE = new ResourceLocation(TreasureRainbowMod.MOD_ID, "textures/entity/halo.png");

    private final ModelPart ring;

    public HaloLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent, EntityModelSet models) {
        super(parent);
        this.ring = models.bakeLayer(LAYER);
    }

    /** Un octógono de 8 segmentos finos. */
    public static LayerDefinition createRing() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        float radius = 5.0F;
        for (int i = 0; i < 8; i++) {
            float angle = i * (float) (Math.PI / 4.0D);
            root.addOrReplaceChild("seg" + i,
                    CubeListBuilder.create().texOffs(0, 0).addBox(-2.2F, -0.5F, -0.6F, 4.4F, 1.0F, 1.2F),
                    PartPose.offsetAndRotation(Mth.cos(angle) * radius, 0.0F, Mth.sin(angle) * radius,
                            0.0F, -angle - (float) (Math.PI / 2.0D), 0.0F));
        }
        return LayerDefinition.create(mesh, 16, 16);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (!(ClientHaloCache.get(player.getId()).getItem() instanceof AngelHaloItem) || player.isInvisible()) {
            return;
        }
        poseStack.pushPose();
        this.getParentModel().head.translateAndRotate(poseStack);
        poseStack.translate(0.0F, -0.70F + Mth.sin(ageInTicks * 0.1F) * 0.02F, 0.0F);
        VertexConsumer consumer = buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        this.ring.render(poseStack, consumer, 15728880, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
        poseStack.popPose();
    }
}
