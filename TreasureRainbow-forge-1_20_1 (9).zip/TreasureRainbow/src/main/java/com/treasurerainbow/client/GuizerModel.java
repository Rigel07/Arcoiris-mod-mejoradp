package com.treasurerainbow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.treasurerainbow.TreasureRainbowMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/** Modelo generado: GuizerModel. */
public class GuizerModel<T extends Entity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(TreasureRainbowMod.MOD_ID, "guizer"), "main");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart helmet;
    private final ModelPart horn_r;
    private final ModelPart horn_l;
    private final ModelPart nose;
    private final ModelPart beard;
    private final ModelPart arm_r;
    private final ModelPart arm_l;
    private final ModelPart torch;
    private final ModelPart shield;
    private final ModelPart leg_r;
    private final ModelPart leg_l;

    public GuizerModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = root.getChild("head");
        this.helmet = root.getChild("head").getChild("helmet");
        this.horn_r = root.getChild("head").getChild("horn_r");
        this.horn_l = root.getChild("head").getChild("horn_l");
        this.nose = root.getChild("head").getChild("nose");
        this.beard = root.getChild("head").getChild("beard");
        this.arm_r = root.getChild("arm_r");
        this.arm_l = root.getChild("arm_l");
        this.torch = root.getChild("arm_r").getChild("torch");
        this.shield = root.getChild("arm_l").getChild("shield");
        this.leg_r = root.getChild("leg_r");
        this.leg_l = root.getChild("leg_l");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(102, 0).addBox(-4F, 0F, -2F, 8F, 12F, 4F), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4F, -8F, -4F, 8F, 8F, 8F), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition p_helmet = p_head.addOrReplaceChild("helmet", CubeListBuilder.create().texOffs(32, 0).addBox(-4.5F, -9F, -4.5F, 9F, 4F, 9F), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition p_horn_r = p_head.addOrReplaceChild("horn_r", CubeListBuilder.create().texOffs(68, 0).addBox(-1F, -5F, -1F, 2F, 5F, 2F), PartPose.offsetAndRotation(-4.5F, -8F, 0F, 0F, 0F, -0.6F));
        PartDefinition p_horn_l = p_head.addOrReplaceChild("horn_l", CubeListBuilder.create().texOffs(68, 0).addBox(-1F, -5F, -1F, 2F, 5F, 2F), PartPose.offsetAndRotation(4.5F, -8F, 0F, 0F, 0F, 0.6F));
        PartDefinition p_nose = p_head.addOrReplaceChild("nose", CubeListBuilder.create().texOffs(76, 0).addBox(-1F, -4F, -6F, 2F, 3F, 2F), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition p_beard = p_head.addOrReplaceChild("beard", CubeListBuilder.create().texOffs(84, 0).addBox(-3.5F, -2F, -5.5F, 7F, 6F, 2F), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition p_arm_r = root.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(0, 16).addBox(-3F, -2F, -2F, 4F, 12F, 4F), PartPose.offsetAndRotation(-5F, 2F, 0F, 0F, 0F, 0F));
        PartDefinition p_arm_l = root.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(0, 16).addBox(-1F, -2F, -2F, 4F, 12F, 4F), PartPose.offsetAndRotation(5F, 2F, 0F, 0F, 0F, 0F));
        PartDefinition p_torch = p_arm_r.addOrReplaceChild("torch", CubeListBuilder.create().texOffs(52, 16).addBox(-1F, 3F, -5F, 2F, 8F, 2F), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition p_shield = p_arm_l.addOrReplaceChild("shield", CubeListBuilder.create().texOffs(32, 16).addBox(3F, 0F, -4.5F, 1F, 9F, 9F), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_r = root.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(16, 16).addBox(-2F, 0F, -2F, 4F, 12F, 4F), PartPose.offsetAndRotation(-2F, 12F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_l = root.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(16, 16).addBox(-2F, 0F, -2F, 4F, 12F, 4F), PartPose.offsetAndRotation(2F, 12F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        this.head.xRot = headPitch * Mth.DEG_TO_RAD;
        float swing = limbSwing * 0.6662F;
        this.leg_r.xRot = Mth.cos(swing) * 1.4F * limbSwingAmount;
        this.leg_l.xRot = Mth.cos(swing + Mth.PI) * 1.4F * limbSwingAmount;
        this.arm_r.xRot = -0.9F + Mth.cos(swing + Mth.PI) * 0.5F * limbSwingAmount;
        this.arm_l.xRot = Mth.cos(swing) * 1.2F * limbSwingAmount;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
