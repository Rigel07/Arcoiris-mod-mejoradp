package com.treasurerainbow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.treasurerainbow.TreasureRainbowMod;
import com.treasurerainbow.entity.CupidEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class CupidRenderer extends MobRenderer<CupidEntity, CupidModel<CupidEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(TreasureRainbowMod.MOD_ID, "textures/entity/cupid.png");

    public CupidRenderer(EntityRendererProvider.Context context) {
        super(context, new CupidModel<>(context.bakeLayer(CupidModel.LAYER)), 0.25F);
    }

    @Override
    public ResourceLocation getTextureLocation(CupidEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(CupidEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(0.9F, 0.9F, 0.9F);
    }
}
