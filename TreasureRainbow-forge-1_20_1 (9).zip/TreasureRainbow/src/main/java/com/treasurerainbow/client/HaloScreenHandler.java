package com.treasurerainbow.client;

import com.treasurerainbow.TreasureRainbowMod;
import com.treasurerainbow.halo.ClientHaloCache;
import com.treasurerainbow.net.HaloClickPacket;
import com.treasurerainbow.net.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * El hueco del Halo Angelical: una casilla nueva en el inventario, justo encima del hueco del casco.
 * Se dibuja sobre la pantalla del inventario y sus clics se envían al servidor.
 */
@Mod.EventBusSubscriber(modid = TreasureRainbowMod.MOD_ID, value = Dist.CLIENT)
public class HaloScreenHandler {
    private static final int SIZE = 18;

    private static int slotX(InventoryScreen screen) {
        return screen.getGuiLeft() + 7;
    }

    private static int slotY(InventoryScreen screen) {
        return screen.getGuiTop() - 21;
    }

    private static boolean inside(InventoryScreen screen, double mx, double my) {
        int x = slotX(screen);
        int y = slotY(screen);
        return mx >= x && mx < x + SIZE && my >= y && my < y + SIZE;
    }

    @SubscribeEvent
    public static void onRender(ScreenEvent.Render.Post event) {
        if (!(event.getScreen() instanceof InventoryScreen screen) || Minecraft.getInstance().player == null) {
            return;
        }
        GuiGraphics graphics = event.getGuiGraphics();
        int x = slotX(screen);
        int y = slotY(screen);
        // marco de la casilla (estilo hueco de inventario)
        graphics.fill(x - 1, y - 1, x + SIZE + 1, y + SIZE + 1, 0xFF373737);
        graphics.fill(x, y, x + SIZE, y + SIZE, 0xFF8B8B8B);
        graphics.fill(x + 1, y + 1, x + SIZE - 1, y + SIZE - 1, 0xFF8B8B8B);

        ItemStack halo = ClientHaloCache.get(Minecraft.getInstance().player.getId());
        if (halo.isEmpty()) {
            // anillo dorado de pista
            graphics.fill(x + 5, y + 4, x + 13, y + 5, 0xFFFFD700);
            graphics.fill(x + 5, y + 9, x + 13, y + 10, 0xFFFFD700);
            graphics.fill(x + 4, y + 5, x + 5, y + 9, 0xFFFFD700);
            graphics.fill(x + 13, y + 5, x + 14, y + 9, 0xFFFFD700);
        } else {
            graphics.renderItem(halo, x + 1, y + 1);
        }
        boolean hover = inside(screen, event.getMouseX(), event.getMouseY());
        if (hover) {
            graphics.fill(x, y, x + SIZE, y + SIZE, 0x80FFFFFF);
            if (halo.isEmpty()) {
                graphics.renderTooltip(Minecraft.getInstance().font, Component.translatable("gui.treasure_rainbow.halo_slot"),
                        event.getMouseX(), event.getMouseY());
            } else {
                graphics.renderTooltip(Minecraft.getInstance().font, halo, event.getMouseX(), event.getMouseY());
            }
        }
    }

    @SubscribeEvent
    public static void onClick(ScreenEvent.MouseButtonPressed.Pre event) {
        if (event.getScreen() instanceof InventoryScreen screen && event.getButton() <= 1
                && inside(screen, event.getMouseX(), event.getMouseY())) {
            ModNetwork.CHANNEL.sendToServer(new HaloClickPacket());
            event.setCanceled(true);
        }
    }
}
