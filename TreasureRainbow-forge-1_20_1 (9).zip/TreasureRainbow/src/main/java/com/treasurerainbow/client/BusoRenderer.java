package com.treasurerainbow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.treasurerainbow.TreasureRainbowMod;
import com.treasurerainbow.entity.BusoEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class BusoRenderer extends MobRenderer<BusoEntity, BusoModel<BusoEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(TreasureRainbowMod.MOD_ID, "textures/entity/buso.png");

    public BusoRenderer(EntityRendererProvider.Context context) {
        super(context, new BusoModel<>(context.bakeLayer(BusoModel.LAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(BusoEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(BusoEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.1F, 1.1F, 1.1F);
    }
}
