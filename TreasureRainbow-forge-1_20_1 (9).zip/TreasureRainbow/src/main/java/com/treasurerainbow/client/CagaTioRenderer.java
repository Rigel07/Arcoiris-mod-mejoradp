package com.treasurerainbow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.treasurerainbow.TreasureRainbowMod;
import com.treasurerainbow.entity.CagaTioEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class CagaTioRenderer extends MobRenderer<CagaTioEntity, CagaTioModel<CagaTioEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(TreasureRainbowMod.MOD_ID, "textures/entity/caga_tio.png");

    public CagaTioRenderer(EntityRendererProvider.Context context) {
        super(context, new CagaTioModel<>(context.bakeLayer(CagaTioModel.LAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(CagaTioEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(CagaTioEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.3F, 1.3F, 1.3F);
    }
}
