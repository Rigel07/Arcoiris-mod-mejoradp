package com.treasurerainbow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.treasurerainbow.TreasureRainbowMod;
import com.treasurerainbow.entity.ElfEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Elfo: reutiliza el modelo del duende con su propia textura. */
public class ElfRenderer extends MobRenderer<ElfEntity, LeprechaunModel<ElfEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(TreasureRainbowMod.MOD_ID, "textures/entity/elf.png");

    public ElfRenderer(EntityRendererProvider.Context context) {
        super(context, new LeprechaunModel<>(context.bakeLayer(LeprechaunModel.LAYER)), 0.35F);
    }

    @Override
    public ResourceLocation getTextureLocation(ElfEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(ElfEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(0.7F, 0.7F, 0.7F);
    }
}
