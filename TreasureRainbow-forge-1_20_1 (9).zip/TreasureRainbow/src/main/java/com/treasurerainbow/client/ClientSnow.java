package com.treasurerainbow.client;

import com.treasurerainbow.ModRegistry;
import com.treasurerainbow.TreasureRainbowMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Copos de nieve alrededor del jugador durante la Navidad, en cualquier bioma (solo donde le da el cielo). */
@Mod.EventBusSubscriber(modid = TreasureRainbowMod.MOD_ID, value = Dist.CLIENT)
public class ClientSnow {

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        ClientLevel level = mc.level;
        if (player == null || level == null || mc.isPaused() || !player.hasEffect(ModRegistry.CHRISTMAS_SPIRIT.get())) {
            return;
        }
        RandomSource random = level.random;
        for (int i = 0; i < 22; i++) {
            double x = player.getX() + (random.nextDouble() - 0.5D) * 34.0D;
            double z = player.getZ() + (random.nextDouble() - 0.5D) * 34.0D;
            double y = player.getY() + 3.0D + random.nextDouble() * 12.0D;
            if (y < level.getHeight(Heightmap.Types.MOTION_BLOCKING, (int) Math.floor(x), (int) Math.floor(z))) {
                continue;
            }
            level.addParticle(ParticleTypes.SNOWFLAKE, x, y, z,
                    (random.nextDouble() - 0.5D) * 0.03D, -0.1D - random.nextDouble() * 0.06D, (random.nextDouble() - 0.5D) * 0.03D);
        }
    }
}
