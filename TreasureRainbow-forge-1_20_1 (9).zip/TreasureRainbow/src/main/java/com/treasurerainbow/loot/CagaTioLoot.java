package com.treasurerainbow.loot;

import com.treasurerainbow.ModRegistry;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Lo que "caga" el Caga Tió: dulces, regalitos y, a veces, objetos de los mods instalados. */
public final class CagaTioLoot {
    private CagaTioLoot() {}

    private record Entry(int weight, Supplier<ItemStack> stack) {}

    private static ItemStack range(RandomSource r, Item item, int lo, int hi) {
        return new ItemStack(item, lo + r.nextInt(hi - lo + 1));
    }

    private static List<Entry> entries(RandomSource r) {
        List<Entry> list = new ArrayList<>();
        list.add(new Entry(14, () -> range(r, ModRegistry.TORRO.get(), 2, 4)));
        list.add(new Entry(10, () -> range(r, Items.COOKIE, 4, 8)));
        list.add(new Entry(6, () -> range(r, Items.SUGAR, 4, 10)));
        list.add(new Entry(6, () -> range(r, Items.COCOA_BEANS, 4, 8)));
        list.add(new Entry(6, () -> range(r, Items.SWEET_BERRIES, 6, 12)));
        list.add(new Entry(5, () -> range(r, Items.HONEY_BOTTLE, 1, 2)));
        list.add(new Entry(8, () -> range(r, Items.GOLD_NUGGET, 3, 8)));
        list.add(new Entry(5, () -> range(r, Items.EMERALD, 1, 3)));
        list.add(new Entry(4, () -> new ItemStack(Items.CAKE)));
        list.add(new Entry(5, () -> range(r, Items.PUMPKIN_PIE, 2, 4)));
        list.add(new Entry(5, () -> range(r, Items.FIREWORK_ROCKET, 2, 5)));
        list.add(new Entry(4, () -> range(r, ModRegistry.RAINBOW_DUST.get(), 1, 4)));
        list.add(new Entry(3, () -> new ItemStack(Items.GOLDEN_APPLE)));
        list.add(new Entry(3, () -> range(r, Items.EXPERIENCE_BOTTLE, 2, 5)));
        list.add(new Entry(2, () -> new ItemStack(Items.DIAMOND)));
        return list;
    }

    /** {@code count} regalitos. */
    public static List<ItemStack> roll(RandomSource random, int count) {
        List<Entry> entries = entries(random);
        int total = 0;
        for (Entry e : entries) {
            total += e.weight();
        }
        List<ItemStack> out = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            int pick = random.nextInt(total);
            for (Entry e : entries) {
                pick -= e.weight();
                if (pick < 0) {
                    out.add(e.stack().get());
                    break;
                }
            }
        }
        if (random.nextFloat() < 0.5F) {
            ItemStack stack = LegendaryLoot.randomModded(random);
            if (!stack.isEmpty()) {
                out.add(stack);
            }
        }
        if (random.nextFloat() < 0.1F) {
            ItemStack stack = LegendaryLoot.randomValuable(random);
            if (!stack.isEmpty()) {
                out.add(stack);
            }
        }
        return out;
    }
}
