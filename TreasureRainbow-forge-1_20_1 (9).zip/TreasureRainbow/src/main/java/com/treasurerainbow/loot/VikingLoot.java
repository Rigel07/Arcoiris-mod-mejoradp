package com.treasurerainbow.loot;

import com.treasurerainbow.ModRegistry;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Botín de la galera vikinga: equipo y provisiones nórdicas + objetos de los mods instalados. */
public final class VikingLoot {
    private VikingLoot() {}

    private record Entry(int weight, Supplier<ItemStack> stack) {}

    private static ItemStack range(RandomSource r, Item item, int lo, int hi) {
        return new ItemStack(item, lo + r.nextInt(hi - lo + 1));
    }

    private static List<Entry> entries(RandomSource r) {
        List<Entry> list = new ArrayList<>();
        list.add(new Entry(10, () -> range(r, Items.IRON_INGOT, 6, 14)));
        list.add(new Entry(8, () -> range(r, Items.GOLD_INGOT, 4, 10)));
        list.add(new Entry(7, () -> range(r, Items.EMERALD, 3, 8)));
        list.add(new Entry(6, () -> range(r, Items.LEATHER, 4, 8)));
        list.add(new Entry(6, () -> range(r, Items.ARROW, 16, 32)));
        list.add(new Entry(6, () -> range(r, Items.COOKED_PORKCHOP, 6, 12)));
        list.add(new Entry(5, () -> range(r, Items.BREAD, 6, 12)));
        list.add(new Entry(5, () -> new ItemStack(Items.IRON_AXE)));
        list.add(new Entry(5, () -> new ItemStack(Items.SHIELD)));
        list.add(new Entry(4, () -> new ItemStack(Items.IRON_SWORD)));
        list.add(new Entry(4, () -> new ItemStack(Items.IRON_CHESTPLATE)));
        list.add(new Entry(3, () -> range(r, Items.ENDER_PEARL, 1, 3)));
        list.add(new Entry(3, () -> range(r, Items.DIAMOND, 1, 2)));
        list.add(new Entry(2, () -> new ItemStack(Items.NETHERITE_SCRAP)));
        list.add(new Entry(2, () -> new ItemStack(Items.GOLDEN_APPLE)));
        list.add(new Entry(8, () -> range(r, ModRegistry.MEAD.get(), 1, 3)));
        list.add(new Entry(3, () -> new ItemStack(ModRegistry.GUIZER_HELMET.get())));
        list.add(new Entry(4, () -> range(r, Items.TORCH, 8, 16)));
        return list;
    }

    public static List<ItemStack> roll(RandomSource random) {
        List<Entry> entries = entries(random);
        int total = 0;
        for (Entry e : entries) {
            total += e.weight();
        }
        List<ItemStack> out = new ArrayList<>();
        int count = 6 + random.nextInt(4);
        for (int i = 0; i < count; i++) {
            int pick = random.nextInt(total);
            for (Entry e : entries) {
                pick -= e.weight();
                if (pick < 0) {
                    out.add(e.stack().get());
                    break;
                }
            }
        }
        int modded = 1 + random.nextInt(3);
        for (int i = 0; i < modded; i++) {
            ItemStack stack = LegendaryLoot.randomModded(random);
            if (!stack.isEmpty()) {
                out.add(stack);
            }
        }
        if (random.nextFloat() < 0.35F) {
            ItemStack stack = LegendaryLoot.randomValuable(random);
            if (!stack.isEmpty()) {
                out.add(stack);
            }
        }
        return out;
    }
}
