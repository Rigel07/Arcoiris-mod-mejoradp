package com.treasurerainbow.entity;

import com.treasurerainbow.item.BusoMaskItem;
import com.treasurerainbow.world.BusojarasEvent;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Busó de Mohács: máscara de madera con cuernos, piel de oveja y cencerro. Persigue a los jugadores haciendo
 * ruido y los empuja (no hace daño), y espanta a los monstruos. Si llevas una Máscara de Busó te toma por uno
 * de los suyos. Se va al amanecer.
 */
public class BusoEntity extends PathfinderMob {
    private boolean eventBound;
    private int noiseCooldown = 40;

    public BusoEntity(EntityType<? extends BusoEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 30.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.FOLLOW_RANGE, 20.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.4D);
    }

    public void setEventBound(boolean eventBound) {
        this.eventBound = eventBound;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15D, true));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.9D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false,
                target -> target instanceof Player player && !BusoMaskItem.isWearing(player)));
    }

    /** Un "ataque" de busó: empujón y estruendo de cencerro, sin daño. */
    @Override
    public boolean doHurtTarget(Entity target) {
        this.swing(InteractionHand.MAIN_HAND);
        if (target instanceof LivingEntity living) {
            living.knockback(0.8D, this.getX() - target.getX(), this.getZ() - target.getZ());
            this.level().playSound(null, this.blockPosition(), SoundEvents.BELL_BLOCK, SoundSource.HOSTILE, 1.5F, 0.6F);
            if (this.level() instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(ParticleTypes.NOTE, target.getX(), target.getY() + 1.8D, target.getZ(), 6, 0.3D, 0.3D, 0.3D, 1.0D);
            }
        }
        return true;
    }

    /** Hace huir a los monstruos cercanos al centro dado. */
    public static void scareMonsters(ServerLevel level, Vec3 center, double radius) {
        net.minecraft.world.phys.AABB box = new net.minecraft.world.phys.AABB(center, center).inflate(radius);
        for (Monster monster : level.getEntitiesOfClass(Monster.class, box)) {
            monster.setTarget(null);
            Vec3 away = DefaultRandomPos.getPosAway(monster, 14, 6, center);
            if (away != null) {
                monster.getNavigation().moveTo(away.x, away.y, away.z, 1.3D);
            }
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            if (this.random.nextInt(25) == 0) {
                this.level().addParticle(ParticleTypes.NOTE, this.getX(), this.getY() + 2.2D, this.getZ(), this.random.nextDouble(), 0.0D, 0.0D);
            }
            return;
        }
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        if (this.eventBound && this.tickCount % 20 == 0 && !BusojarasEvent.isActive(serverLevel)) {
            serverLevel.sendParticles(ParticleTypes.CLOUD, this.getX(), this.getY() + 1.0D, this.getZ(), 20, 0.4D, 0.8D, 0.4D, 0.05D);
            this.discard();
            return;
        }
        if (--this.noiseCooldown <= 0) {
            this.noiseCooldown = 50 + this.random.nextInt(50);
            serverLevel.playSound(null, this.blockPosition(), SoundEvents.BELL_BLOCK, SoundSource.NEUTRAL, 0.9F, 0.5F + this.random.nextFloat() * 0.2F);
            serverLevel.playSound(null, this.blockPosition(), SoundEvents.WOOD_HIT, SoundSource.NEUTRAL, 1.0F, 0.7F);
        }
        if (this.tickCount % 20 == 0) {
            scareMonsters(serverLevel, this.position(), 12.0D);
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.VILLAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.VILLAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.VILLAGER_DEATH;
    }

    @Override
    public float getVoicePitch() {
        return 0.5F + this.random.nextFloat() * 0.15F;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("EventBound", this.eventBound);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.eventBound = tag.getBoolean("EventBound");
    }
}
