package com.treasurerainbow.entity;

import com.treasurerainbow.ModRegistry;
import com.treasurerainbow.world.UpHellyAaEvent;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Guizer vikingo del Up Helly Aa: desfila con una antorcha y da antorchas e hidromiel (una vez). */
public class GuizerEntity extends PathfinderMob {
    private boolean eventBound;
    private boolean gifted;

    public GuizerEntity(EntityType<? extends GuizerEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 24.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.FOLLOW_RANGE, 16.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.3D);
    }

    public void setEventBound(boolean eventBound) {
        this.eventBound = eventBound;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.4D));
        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResult.PASS;
        }
        if (!this.level().isClientSide) {
            if (!this.gifted) {
                this.gifted = true;
                give(player, new ItemStack(Items.TORCH, 3));
                give(player, new ItemStack(ModRegistry.MEAD.get()));
                this.playSound(SoundEvents.VILLAGER_YES, 1.0F, 0.6F);
                player.displayClientMessage(Component.translatable("message.treasure_rainbow.guizer_gift"), true);
            } else {
                this.playSound(SoundEvents.VILLAGER_CELEBRATE, 1.0F, 0.6F);
                player.displayClientMessage(Component.translatable("message.treasure_rainbow.guizer_cheer"), true);
            }
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    private static void give(Player player, ItemStack stack) {
        if (!player.getInventory().add(stack)) {
            player.drop(stack, false);
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            // llama de la antorcha en la mano derecha
            Vec3 look = Vec3.directionFromRotation(0.0F, this.yBodyRot);
            double tx = this.getX() + look.x * 0.5D - look.z * 0.45D;
            double tz = this.getZ() + look.z * 0.5D + look.x * 0.45D;
            this.level().addParticle(ParticleTypes.FLAME, tx, this.getY() + 1.55D, tz, 0.0D, 0.01D, 0.0D);
            if (this.random.nextInt(4) == 0) {
                this.level().addParticle(ParticleTypes.SMOKE, tx, this.getY() + 1.7D, tz, 0.0D, 0.03D, 0.0D);
            }
            return;
        }
        if (this.level() instanceof ServerLevel serverLevel && this.eventBound && this.tickCount % 20 == 0
                && !UpHellyAaEvent.isActive(serverLevel)) {
            serverLevel.sendParticles(ParticleTypes.LARGE_SMOKE, this.getX(), this.getY() + 1.0D, this.getZ(),
                    20, 0.4D, 0.7D, 0.4D, 0.04D);
            this.discard();
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.VILLAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.VILLAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.VILLAGER_DEATH;
    }

    @Override
    public float getVoicePitch() {
        return 0.55F + this.random.nextFloat() * 0.15F;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("EventBound", this.eventBound);
        tag.putBoolean("Gifted", this.gifted);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.eventBound = tag.getBoolean("EventBound");
        this.gifted = tag.getBoolean("Gifted");
    }
}
