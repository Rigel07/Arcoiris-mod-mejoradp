package com.treasurerainbow.entity;

import com.treasurerainbow.ModRegistry;
import com.treasurerainbow.loot.CagaTioLoot;
import com.treasurerainbow.world.CagaTioEvent;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * El Caga Tió: un tronco sonriente con barretina y manta. Se le da de comer (clic derecho con comida)
 * y cuando está bien alimentado se le pega con un palo (clic derecho con un palo) mientras se canta:
 * ¡caga regalos! Lo último que suelta es una arengada.
 */
public class CagaTioEntity extends PathfinderMob {
    private static final int FED_NEEDED = 3;
    private static final int FED_MAX = 5;
    private static final int HITS_NEEDED = 5;

    private int fed;
    private int hits;
    private boolean eventBound;

    public CagaTioEntity(EntityType<? extends CagaTioEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.2D)
                .add(Attributes.FOLLOW_RANGE, 12.0D);
    }

    public void setEventBound(boolean eventBound) {
        this.eventBound = eventBound;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.5D, 0.01F));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        boolean food = held.isEdible();
        boolean stick = held.is(Items.STICK);
        if (!food && !stick) {
            return InteractionResult.PASS;
        }
        if (this.level().isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return InteractionResult.PASS;
        }
        if (food) {
            if (this.fed >= FED_MAX) {
                return InteractionResult.CONSUME;
            }
            this.fed++;
            if (!player.getAbilities().instabuild) {
                held.shrink(1);
            }
            this.playSound(SoundEvents.GENERIC_EAT, 1.0F, 0.8F);
            serverLevel.sendParticles(ParticleTypes.HEART, this.getX(), this.getY() + 1.0D, this.getZ(), 4, 0.3D, 0.3D, 0.3D, 0.02D);
            player.displayClientMessage(Component.translatable("message.treasure_rainbow.tio_fed", Math.min(this.fed, FED_NEEDED)), true);
            return InteractionResult.CONSUME;
        }
        // palo
        if (this.fed < FED_NEEDED) {
            this.playSound(SoundEvents.VILLAGER_NO, 1.0F, 1.3F);
            player.displayClientMessage(Component.translatable("message.treasure_rainbow.tio_hungry"), true);
            return InteractionResult.CONSUME;
        }
        this.hits++;
        this.playSound(SoundEvents.WOOD_HIT, 1.0F, 1.0F + this.random.nextFloat() * 0.3F);
        serverLevel.sendParticles(ParticleTypes.NOTE, this.getX(), this.getY() + 1.4D, this.getZ(), 3, 0.3D, 0.3D, 0.3D, 1.0D);
        player.displayClientMessage(Component.translatable("message.treasure_rainbow.tio_hit"), true);
        if (this.hits >= HITS_NEEDED) {
            poop(serverLevel, player);
        }
        return InteractionResult.CONSUME;
    }

    /** El Tió caga los regalos por detrás y, al final, una arengada. */
    private void poop(ServerLevel level, Player player) {
        Vec3 look = Vec3.directionFromRotation(0.0F, this.yBodyRot);
        double rx = this.getX() - look.x * 1.0D;
        double rz = this.getZ() - look.z * 1.0D;
        int count = 3 + this.fed;
        for (ItemStack stack : CagaTioLoot.roll(this.random, count)) {
            launch(level, rx, rz, look, stack);
        }
        launch(level, rx, rz, look, new ItemStack(Items.COD));
        if (this.random.nextFloat() < 0.2F) {
            launch(level, rx, rz, look, new ItemStack(ModRegistry.BARRETINA.get()));
        }
        level.sendParticles(ParticleTypes.FIREWORK, rx, this.getY() + 0.6D, rz, 25, 0.3D, 0.3D, 0.3D, 0.15D);
        level.sendParticles(ParticleTypes.HEART, this.getX(), this.getY() + 1.0D, this.getZ(), 8, 0.4D, 0.4D, 0.4D, 0.05D);
        this.playSound(SoundEvents.CHICKEN_EGG, 1.5F, 0.7F);
        this.playSound(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1.0F, 1.2F);
        player.displayClientMessage(Component.translatable("message.treasure_rainbow.tio_done"), true);
        this.fed = 0;
        this.hits = 0;
    }

    private void launch(ServerLevel level, double rx, double rz, Vec3 look, ItemStack stack) {
        ItemEntity item = new ItemEntity(level, rx, this.getY() + 0.6D, rz, stack);
        item.setDeltaMovement(-look.x * 0.15D + (this.random.nextDouble() - 0.5D) * 0.2D, 0.25D,
                -look.z * 0.15D + (this.random.nextDouble() - 0.5D) * 0.2D);
        level.addFreshEntity(item);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            if (this.fed >= FED_NEEDED && this.random.nextInt(10) == 0) {
                this.level().addParticle(ParticleTypes.NOTE, this.getX(), this.getY() + 1.4D, this.getZ(), this.random.nextDouble(), 0.0D, 0.0D);
            }
            return;
        }
        if (this.level() instanceof ServerLevel serverLevel && this.eventBound && this.tickCount % 20 == 0
                && !CagaTioEvent.isActive(serverLevel)) {
            serverLevel.sendParticles(ParticleTypes.CLOUD, this.getX(), this.getY() + 0.8D, this.getZ(), 15, 0.3D, 0.4D, 0.3D, 0.03D);
            this.discard();
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.VILLAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.VILLAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.VILLAGER_DEATH;
    }

    @Override
    public float getVoicePitch() {
        return 1.2F + this.random.nextFloat() * 0.2F;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Fed", this.fed);
        tag.putInt("Hits", this.hits);
        tag.putBoolean("EventBound", this.eventBound);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.fed = tag.getInt("Fed");
        this.hits = tag.getInt("Hits");
        this.eventBound = tag.getBoolean("EventBound");
    }
}
