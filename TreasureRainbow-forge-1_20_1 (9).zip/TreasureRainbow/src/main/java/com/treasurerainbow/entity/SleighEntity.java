package com.treasurerainbow.entity;

import com.treasurerainbow.ModRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * El trineo de Navidad: cruza el cielo (con renos) y va soltando regalos que caen al suelo.
 * Solo se mueve en el servidor; el cliente recibe la posición con los paquetes normales.
 */
public class SleighEntity extends Entity {
    private static final int LIFE = 800;
    private static final double SPEED = 0.45D;
    private static final int GIFT_EVERY = 16;

    private int life = LIFE;

    public SleighEntity(EntityType<? extends SleighEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        setNoGravity(true);
    }

    @Override
    protected void defineSynchedData() {
    }

    @Override
    public void tick() {
        super.tick();
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        float rad = this.getYRot() * Mth.DEG_TO_RAD;
        this.setPos(this.getX() - Mth.sin(rad) * SPEED, this.getY(), this.getZ() + Mth.cos(rad) * SPEED);

        // Se va al acabar su tiempo o si ya no hay jugadores cerca (fuera de la zona simulada se quedaría congelado).
        this.life--;
        if (this.life <= 0 || (this.tickCount % 20 == 0
                && this.level().getNearestPlayer(this.getX(), this.getY(), this.getZ(), 140.0D, false) == null)) {
            serverLevel.sendParticles(ParticleTypes.FIREWORK, this.getX(), this.getY() + 1.0D, this.getZ(), 40, 2.0D, 1.0D, 2.0D, 0.1D);
            this.discard();
            return;
        }

        serverLevel.sendParticles(ParticleTypes.SNOWFLAKE, this.getX(), this.getY() + 1.0D, this.getZ(), 4, 1.5D, 0.6D, 1.5D, 0.02D);
        if (this.tickCount % 3 == 0) {
            serverLevel.sendParticles(ParticleTypes.END_ROD, this.getX(), this.getY() + 1.0D, this.getZ(), 1, 1.0D, 0.4D, 1.0D, 0.01D);
        }
        if (this.tickCount % 15 == 0) {
            serverLevel.playSound(null, this.blockPosition(), SoundEvents.BELL_BLOCK, SoundSource.NEUTRAL, 4.0F, 1.6F);
            serverLevel.playSound(null, this.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.NEUTRAL, 4.0F, 1.8F);
        }
        if (this.tickCount % GIFT_EVERY == 0
                && this.level().getNearestPlayer(this.getX(), this.getY(), this.getZ(), 90.0D, false) != null) {
            dropGift(serverLevel);
        }
    }

    private void dropGift(ServerLevel serverLevel) {
        BlockPos pos = BlockPos.containing(this.getX() + (this.random.nextDouble() - 0.5D) * 6.0D, this.getY() - 2.0D,
                this.getZ() + (this.random.nextDouble() - 0.5D) * 6.0D);
        if (!serverLevel.hasChunkAt(pos) || !serverLevel.getBlockState(pos).isAir()) {
            return;
        }
        BlockState gift = ModRegistry.GIFT.get().defaultBlockState()
                .setValue(com.treasurerainbow.block.GiftBlock.COLOR, this.random.nextInt(4));
        FallingBlockEntity.fall(serverLevel, pos, gift);
    }

    // ------------------------------------------------------- Comportamiento

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    @Override
    public boolean shouldRender(double x, double y, double z) {
        return true;
    }

    @Override
    public AABB getBoundingBoxForCulling() {
        return this.getBoundingBox().inflate(40.0D);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        if (tag.contains("Life")) {
            this.life = tag.getInt("Life");
        }
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Life", this.life);
    }
}
