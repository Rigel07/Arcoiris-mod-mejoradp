package com.treasurerainbow.block;

import com.treasurerainbow.loot.VikingLoot;
import com.treasurerainbow.world.UpHellyAaEvent;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Galera vikinga del Up Helly Aa. Durante el festival se quema con una antorcha (o mechero) y suelta su botín.
 * Las galeras "naturales" que aparecen durante la noche desaparecen al amanecer.
 */
public class LongshipBlock extends Block {
    public static final BooleanProperty NATURAL = BooleanProperty.create("natural");
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    private static final VoxelShape SHAPE = Block.box(0.0D, 0.0D, 0.0D, 16.0D, 14.0D, 16.0D);

    public LongshipBlock(Properties properties) {
        super(properties);
        registerDefaultState(this.stateDefinition.any().setValue(NATURAL, false).setValue(FACING, net.minecraft.core.Direction.EAST));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(NATURAL, FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection());
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean isMoving) {
        if (!level.isClientSide && state.getValue(NATURAL)) {
            level.scheduleTick(pos, this, 100);
        }
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(NATURAL) && !UpHellyAaEvent.isActive(level)) {
            level.sendParticles(ParticleTypes.LARGE_SMOKE, pos.getX() + 0.5D, pos.getY() + 0.8D, pos.getZ() + 0.5D,
                    15, 0.4D, 0.4D, 0.4D, 0.03D);
            level.removeBlock(pos, false);
        } else if (state.getValue(NATURAL)) {
            level.scheduleTick(pos, this, 100);
        }
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand,
                                 BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);
        boolean consumable = held.is(Items.TORCH) || held.is(Items.SOUL_TORCH) || held.is(Items.FIRE_CHARGE);
        boolean lighter = held.is(Items.FLINT_AND_STEEL);
        if (!consumable && !lighter) {
            return InteractionResult.PASS;
        }
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        ServerLevel serverLevel = (ServerLevel) level;
        if (!UpHellyAaEvent.isActive(serverLevel)) {
            player.displayClientMessage(Component.translatable("message.treasure_rainbow.longship_no_event"), true);
            return InteractionResult.CONSUME;
        }
        if (!player.getAbilities().instabuild) {
            if (consumable) {
                held.shrink(1);
            } else {
                held.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
            }
        }
        serverLevel.removeBlock(pos, false);
        for (ItemStack stack : VikingLoot.roll(serverLevel.random)) {
            Block.popResource(serverLevel, pos, stack);
        }
        serverLevel.sendParticles(ParticleTypes.FLAME, pos.getX() + 0.5D, pos.getY() + 0.8D, pos.getZ() + 0.5D, 80, 0.7D, 0.6D, 0.7D, 0.08D);
        serverLevel.sendParticles(ParticleTypes.LAVA, pos.getX() + 0.5D, pos.getY() + 0.8D, pos.getZ() + 0.5D, 20, 0.6D, 0.5D, 0.6D, 0.0D);
        serverLevel.sendParticles(ParticleTypes.LARGE_SMOKE, pos.getX() + 0.5D, pos.getY() + 1.2D, pos.getZ() + 0.5D, 25, 0.5D, 0.7D, 0.5D, 0.05D);
        serverLevel.playSound(null, pos, SoundEvents.BLAZE_SHOOT, SoundSource.BLOCKS, 1.5F, 0.7F);
        serverLevel.playSound(null, pos, SoundEvents.FIRECHARGE_USE, SoundSource.BLOCKS, 1.5F, 0.8F);
        player.displayClientMessage(Component.translatable("message.treasure_rainbow.longship_burned"), true);
        return InteractionResult.CONSUME;
    }
}
