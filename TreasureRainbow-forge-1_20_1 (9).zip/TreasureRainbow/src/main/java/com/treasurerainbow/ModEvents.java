package com.treasurerainbow;

import com.treasurerainbow.entity.BusoEntity;
import com.treasurerainbow.entity.CagaTioEntity;
import com.treasurerainbow.entity.CrazyBirdEntity;
import com.treasurerainbow.entity.CupidEntity;
import com.treasurerainbow.entity.ElfEntity;
import com.treasurerainbow.entity.GuizerEntity;
import com.treasurerainbow.entity.LeprechaunEntity;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Eventos del bus del mod (atributos de las entidades). */
@Mod.EventBusSubscriber(modid = TreasureRainbowMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModRegistry.LEPRECHAUN.get(), LeprechaunEntity.createAttributes().build());
        event.put(ModRegistry.CRAZY_BIRD.get(), CrazyBirdEntity.createAttributes().build());
        event.put(ModRegistry.ELF.get(), ElfEntity.createAttributes().build());
        event.put(ModRegistry.CUPID.get(), CupidEntity.createAttributes().build());
        event.put(ModRegistry.BUSO.get(), BusoEntity.createAttributes().build());
        event.put(ModRegistry.GUIZER.get(), GuizerEntity.createAttributes().build());
        event.put(ModRegistry.CAGA_TIO.get(), CagaTioEntity.createAttributes().build());
    }
}
