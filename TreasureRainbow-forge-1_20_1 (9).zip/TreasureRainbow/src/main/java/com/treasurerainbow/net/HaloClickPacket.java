package com.treasurerainbow.net;

import com.treasurerainbow.halo.HaloEvents;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Cliente -> servidor: he hecho clic en el hueco del halo. */
public class HaloClickPacket {
    public static void encode(HaloClickPacket msg, FriendlyByteBuf buf) {
    }

    public static HaloClickPacket decode(FriendlyByteBuf buf) {
        return new HaloClickPacket();
    }

    public static void handle(HaloClickPacket msg, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player != null) {
                HaloEvents.handleClick(player);
            }
        });
        context.setPacketHandled(true);
    }
}
