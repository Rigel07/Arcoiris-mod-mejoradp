package com.treasurerainbow.world;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Lanza cohetes de colores que suben al cielo y explotan. */
public final class FestiveFireworks {
    private FestiveFireworks() {}

    public static final int[] MULTI = {0xFF4500, 0xFFD700, 0xFF69B4, 0x00BFFF, 0x7CFC00, 0xFFFFFF, 0xB066FF};
    public static final int[] YELLOWS = {0xFFD700, 0xFFEB3B, 0xFFF176, 0xFFC107};

    public static void launch(ServerLevel level, double x, double y, double z, RandomSource random, int[] palette, int flight) {
        ItemStack rocket = new ItemStack(Items.FIREWORK_ROCKET);
        CompoundTag fireworks = rocket.getOrCreateTagElement("Fireworks");
        fireworks.putByte("Flight", (byte) flight);
        ListTag explosions = new ListTag();
        CompoundTag explosion = new CompoundTag();
        explosion.putByte("Type", (byte) (random.nextBoolean() ? 1 : 4));
        explosion.putByte("Flicker", (byte) 1);
        explosion.putByte("Trail", (byte) 1);
        explosion.putIntArray("Colors", new int[]{palette[random.nextInt(palette.length)], palette[random.nextInt(palette.length)]});
        explosion.putIntArray("FadeColors", new int[]{0xFFFFFF});
        explosions.add(explosion);
        fireworks.put("Explosions", explosions);
        level.addFreshEntity(new FireworkRocketEntity(level, x, y, z, rocket));
    }
}
