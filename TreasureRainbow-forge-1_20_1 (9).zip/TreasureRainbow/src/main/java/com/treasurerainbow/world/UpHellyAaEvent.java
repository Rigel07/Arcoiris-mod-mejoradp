package com.treasurerainbow.world;

import com.treasurerainbow.ModRegistry;
import com.treasurerainbow.TreasureRainbowMod;
import com.treasurerainbow.block.LongshipBlock;
import com.treasurerainbow.entity.GuizerEntity;
import com.treasurerainbow.item.GuizerHelmetItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Up Helly Aa (Lerwick, Shetland): festival vikingo del fuego. Cada 7 días del mundo, al caer la noche y hasta
 * el amanecer, los guizers desfilan con antorchas y aparecen galeras vikingas que se queman con una antorcha
 * para ganar su botín. Con el Casco de Guizer puesto eres inmune al fuego y a la lava (siempre).
 */
@Mod.EventBusSubscriber(modid = TreasureRainbowMod.MOD_ID)
public final class UpHellyAaEvent {
    private UpHellyAaEvent() {}

    public static final int INTERVAL_DAYS = 7;
    private static final long NIGHTFALL = 13000L;
    private static final Map<UUID, BlockPos> LAST_SHIP = new HashMap<>();

    public static boolean isActive(MinecraftServer server) {
        return server != null && UpHellyAaData.get(server.overworld()).active;
    }

    public static boolean isActive(ServerLevel level) {
        return isActive(level.getServer());
    }

    public static boolean start(MinecraftServer server) {
        ServerLevel overworld = server.overworld();
        UpHellyAaData data = UpHellyAaData.get(overworld);
        if (data.active) {
            return false;
        }
        long day = overworld.getDayTime() / 24000L;
        data.active = true;
        data.startDay = day;
        data.lastStartedDay = day;
        data.setDirty();
        Component title = Component.translatable("message.treasure_rainbow.uphellyaa_start.title");
        Component subtitle = Component.translatable("message.treasure_rainbow.uphellyaa_start.subtitle");
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.connection.send(new ClientboundSetTitlesAnimationPacket(10, 80, 30));
            player.connection.send(new ClientboundSetSubtitleTextPacket(subtitle));
            player.connection.send(new ClientboundSetTitleTextPacket(title));
            player.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.PLAYERS, 1.0F, 1.0F);
            if (player.level() instanceof ServerLevel level && level.dimension() == Level.OVERWORLD) {
                for (int i = 0; i < 4; i++) {
                    spawnGuizer(level, player);
                }
                maybeSpawnShip(level, player, true);
            }
        }
        server.getPlayerList().broadcastSystemMessage(Component.translatable("message.treasure_rainbow.uphellyaa_start.chat"), false);
        return true;
    }

    public static boolean stop(MinecraftServer server) {
        UpHellyAaData data = UpHellyAaData.get(server.overworld());
        if (!data.active) {
            return false;
        }
        data.active = false;
        data.setDirty();
        LAST_SHIP.clear();
        server.getPlayerList().broadcastSystemMessage(Component.translatable("message.treasure_rainbow.uphellyaa_end"), false);
        return true;
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null || server.getTickCount() % 20 != 0) {
            return;
        }
        ServerLevel overworld = server.overworld();
        UpHellyAaData data = UpHellyAaData.get(overworld);
        long dayTime = overworld.getDayTime();
        long day = dayTime / 24000L;
        long timeOfDay = dayTime % 24000L;

        if (data.active) {
            if (day != data.startDay) {
                stop(server);
            }
        } else if (day % INTERVAL_DAYS == INTERVAL_DAYS - 1 && timeOfDay >= NIGHTFALL && data.lastStartedDay != day) {
            start(server);
        }

        // Casco de Guizer: inmunidad al fuego y a la lava (siempre).
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (!player.isSpectator() && GuizerHelmetItem.isWearing(player)) {
                MobEffectInstance current = player.getEffect(MobEffects.FIRE_RESISTANCE);
                if (current == null || current.getDuration() < 100) {
                    player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 240, 0, false, false, false));
                }
            }
        }

        if (!data.active) {
            return;
        }
        for (ServerPlayer player : overworld.players()) {
            if (player.isSpectator()) {
                continue;
            }
            if (overworld.getEntitiesOfClass(GuizerEntity.class, player.getBoundingBox().inflate(64.0D)).size() < 5
                    && overworld.random.nextDouble() < 0.2D) {
                spawnGuizer(overworld, player);
            }
            maybeSpawnShip(overworld, player, false);
        }
    }

    public static boolean spawnGuizer(ServerLevel level, ServerPlayer player) {
        BlockPos origin = player.blockPosition();
        for (int attempt = 0; attempt < 10; attempt++) {
            double angle = level.random.nextDouble() * Math.PI * 2.0D;
            double distance = 12.0D + level.random.nextInt(18);
            int x = origin.getX() + (int) Math.round(Math.cos(angle) * distance);
            int z = origin.getZ() + (int) Math.round(Math.sin(angle) * distance);
            if (!level.hasChunk(x >> 4, z >> 4)) {
                continue;
            }
            BlockPos pos = new BlockPos(x, level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z), z);
            if (!RainbowSpawner.isFreeSpot(level, pos)) {
                continue;
            }
            GuizerEntity guizer = ModRegistry.GUIZER.get().create(level);
            if (guizer == null) {
                return false;
            }
            guizer.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, level.random.nextFloat() * 360.0F, 0.0F);
            guizer.setEventBound(true);
            level.addFreshEntity(guizer);
            level.sendParticles(ParticleTypes.FLAME, pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D, 15, 0.3D, 0.6D, 0.3D, 0.03D);
            return true;
        }
        return false;
    }

    /** Coloca una galera vikinga "natural" cerca del jugador si no tiene ya una cerca. */
    private static void maybeSpawnShip(ServerLevel level, ServerPlayer player, boolean force) {
        if (!force && level.random.nextDouble() > 0.1D) {
            return;
        }
        BlockPos last = LAST_SHIP.get(player.getUUID());
        if (last != null && level.getBlockState(last).is(ModRegistry.VIKING_LONGSHIP.get())
                && last.distSqr(player.blockPosition()) < 70.0D * 70.0D) {
            return;
        }
        BlockPos origin = player.blockPosition();
        for (int attempt = 0; attempt < 8; attempt++) {
            double angle = level.random.nextDouble() * Math.PI * 2.0D;
            double distance = 18.0D + level.random.nextInt(18);
            int x = origin.getX() + (int) Math.round(Math.cos(angle) * distance);
            int z = origin.getZ() + (int) Math.round(Math.sin(angle) * distance);
            if (!level.hasChunk(x >> 4, z >> 4)) {
                continue;
            }
            BlockPos pos = new BlockPos(x, level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z), z);
            if (!RainbowSpawner.isFreeSpot(level, pos)) {
                continue;
            }
            level.setBlock(pos, ModRegistry.VIKING_LONGSHIP.get().defaultBlockState()
                    .setValue(LongshipBlock.NATURAL, true)
                    .setValue(LongshipBlock.FACING, Direction.from2DDataValue(level.random.nextInt(4))), 3);
            LAST_SHIP.put(player.getUUID(), pos);
            level.sendParticles(ParticleTypes.FLAME, pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D, 25, 0.5D, 0.6D, 0.5D, 0.04D);
            return;
        }
    }
}
