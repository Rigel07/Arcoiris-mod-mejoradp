package com.treasurerainbow.world;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** Estado guardado del evento de San Valentín (vive en el Overworld). */
public class ValentineData extends SavedData {
    private static final String NAME = "treasure_rainbow_valentine";
    public boolean active;
    public long lastDay = -1L;

    public static ValentineData get(ServerLevel overworld) {
        return overworld.getDataStorage().computeIfAbsent(ValentineData::load, ValentineData::new, NAME);
    }

    public static ValentineData load(CompoundTag tag) {
        ValentineData data = new ValentineData();
        data.active = tag.getBoolean("Active");
        data.lastDay = tag.contains("LastDay") ? tag.getLong("LastDay") : -1L;
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("Active", this.active);
        tag.putLong("LastDay", this.lastDay);
        return tag;
    }
}
