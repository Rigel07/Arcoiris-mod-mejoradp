package com.treasurerainbow.world;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** Estado guardado del Busójárás (vive en el Overworld). */
public class BusojarasData extends SavedData {
    private static final String NAME = "treasure_rainbow_busojaras";
    public boolean active;
    public long lastDay = -1L;

    public static BusojarasData get(ServerLevel overworld) {
        return overworld.getDataStorage().computeIfAbsent(BusojarasData::load, BusojarasData::new, NAME);
    }

    public static BusojarasData load(CompoundTag tag) {
        BusojarasData data = new BusojarasData();
        data.active = tag.getBoolean("Active");
        data.lastDay = tag.contains("LastDay") ? tag.getLong("LastDay") : -1L;
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("Active", this.active);
        tag.putLong("LastDay", this.lastDay);
        return tag;
    }
}
