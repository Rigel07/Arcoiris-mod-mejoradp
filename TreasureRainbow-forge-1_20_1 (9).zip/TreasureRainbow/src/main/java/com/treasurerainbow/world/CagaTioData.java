package com.treasurerainbow.world;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** Estado guardado del día del Caga Tió (vive en el Overworld). */
public class CagaTioData extends SavedData {
    private static final String NAME = "treasure_rainbow_caga_tio";
    public boolean active;
    public long lastDay = -1L;

    public static CagaTioData get(ServerLevel overworld) {
        return overworld.getDataStorage().computeIfAbsent(CagaTioData::load, CagaTioData::new, NAME);
    }

    public static CagaTioData load(CompoundTag tag) {
        CagaTioData data = new CagaTioData();
        data.active = tag.getBoolean("Active");
        data.lastDay = tag.contains("LastDay") ? tag.getLong("LastDay") : -1L;
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("Active", this.active);
        tag.putLong("LastDay", this.lastDay);
        return tag;
    }
}
