package com.treasurerainbow.world;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** Estado guardado del Up Helly Aa (vive en el Overworld). */
public class UpHellyAaData extends SavedData {
    private static final String NAME = "treasure_rainbow_up_helly_aa";
    public boolean active;
    public long startDay = -1L;
    public long lastStartedDay = -1L;

    public static UpHellyAaData get(ServerLevel overworld) {
        return overworld.getDataStorage().computeIfAbsent(UpHellyAaData::load, UpHellyAaData::new, NAME);
    }

    public static UpHellyAaData load(CompoundTag tag) {
        UpHellyAaData data = new UpHellyAaData();
        data.active = tag.getBoolean("Active");
        data.startDay = tag.contains("StartDay") ? tag.getLong("StartDay") : -1L;
        data.lastStartedDay = tag.contains("LastStartedDay") ? tag.getLong("LastStartedDay") : -1L;
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("Active", this.active);
        tag.putLong("StartDay", this.startDay);
        tag.putLong("LastStartedDay", this.lastStartedDay);
        return tag;
    }
}
