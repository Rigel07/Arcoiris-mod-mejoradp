package com.treasurerainbow.world;

import com.treasurerainbow.ModRegistry;
import com.treasurerainbow.block.RainbowChestBlock;
import com.treasurerainbow.block.RainbowChestBlockEntity;
import com.treasurerainbow.entity.LeprechaunEntity;
import com.treasurerainbow.entity.RainbowEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Crea arcoíris (con su cofre) en sitios despejados alrededor de un jugador. */
public final class RainbowSpawner {
    private RainbowSpawner() {}

    /** Distancia mínima entre dos arcoíris. */
    private static final double MIN_SPACING = 110.0D;
    /** Probabilidad de que un arcoíris lleve caldero de oro + duende + cofre legendario. */
    private static final double LEPRECHAUN_CHANCE = 0.08D;
    /** La misma probabilidad durante el Día de San Patricio. */
    private static final double LEPRECHAUN_CHANCE_EVENT = 0.35D;
    /** Cuánto tiempo se queda el duende de un arcoíris (ticks): unos 20 minutos. */
    private static final int LEPRECHAUN_STAY = 24000;
    /** Cuánto tiempo se queda un duende que pasea durante el evento (ticks): unos 5 minutos. */
    private static final int WANDERING_STAY = 6000;

    /** Modos para decidir si el arcoíris lleva duende. */
    public static final int SPECIAL_AUTO = 0;
    public static final int SPECIAL_NEVER = 1;
    public static final int SPECIAL_ALWAYS = 2;

    /** Resultado de crear un arcoíris: dónde está el cofre y si es de los especiales (con duende). */
    public record Result(BlockPos pos, boolean special) {}

    /** @return el resultado si se ha creado un arcoíris, o null si no se ha encontrado un buen sitio. */
    public static Result trySpawnNear(ServerLevel level, ServerPlayer player, boolean force, int specialMode) {
        RandomSource random = level.random;
        BlockPos origin = player.blockPosition();

        for (int attempt = 0; attempt < 12; attempt++) {
            double angle = random.nextDouble() * Math.PI * 2.0D;
            double distance = force ? 24.0D + random.nextInt(14) : 50.0D + random.nextInt(40);
            int x = origin.getX() + (int) Math.round(Math.cos(angle) * distance);
            int z = origin.getZ() + (int) Math.round(Math.sin(angle) * distance);
            if (!level.hasChunk(x >> 4, z >> 4)) {
                continue;
            }
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos pos = new BlockPos(x, y, z);
            if (!isGoodSpot(level, pos)) {
                continue;
            }
            if (!force && !level.getEntitiesOfClass(RainbowEntity.class, new AABB(pos).inflate(MIN_SPACING)).isEmpty()) {
                continue;
            }
            boolean special = switch (specialMode) {
                case SPECIAL_ALWAYS -> true;
                case SPECIAL_NEVER -> false;
                default -> random.nextDouble() < (SaintPatrickDay.isActive(level) ? LEPRECHAUN_CHANCE_EVENT : LEPRECHAUN_CHANCE);
            };
            boolean made = spawnRainbow(level, pos, force, special);
            if (made) {
                boolean hasLeprechaun = special && hasCauldronNear(level, pos);
                return new Result(pos, hasLeprechaun);
            }
        }
        return null;
    }

    private static boolean isGoodSpot(ServerLevel level, BlockPos pos) {
        BlockPos below = pos.below();
        BlockState ground = level.getBlockState(below);
        boolean solidGround = ground.isFaceSturdy(level, below, Direction.UP) && ground.getFluidState().isEmpty();
        return solidGround && level.getFluidState(pos).isEmpty() && level.getBlockState(pos).canBeReplaced()
                && level.canSeeSky(pos);
    }

    /** Un hueco donde cabe un bloque o un duende: suelo firme debajo y aire encima. */
    public static boolean isFreeSpot(ServerLevel level, BlockPos pos) {
        BlockPos below = pos.below();
        return level.getBlockState(pos).canBeReplaced()
                && level.getFluidState(pos).isEmpty()
                && level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)
                && level.getBlockState(pos.above()).getCollisionShape(level, pos.above()).isEmpty();
    }

    private static boolean hasCauldronNear(ServerLevel level, BlockPos pos) {
        for (Direction dir : Direction.Plane.HORIZONTAL) {
            if (level.getBlockState(pos.relative(dir)).is(ModRegistry.GOLD_CAULDRON.get())) {
                return true;
            }
        }
        return false;
    }

    /** Planta el cofre en {@code pos} y levanta el arcoíris que acaba en él. */
    public static boolean spawnRainbow(ServerLevel level, BlockPos pos, boolean ignoreDay, boolean special) {
        RandomSource random = level.random;
        float yaw = random.nextFloat() * 360.0F;
        float rad = yaw * Mth.DEG_TO_RAD;
        Direction facing = Direction.getNearest(-Mth.sin(rad), 0.0D, Mth.cos(rad));

        // Los especiales necesitan un hueco al lado para el caldero de oro.
        BlockPos cauldronPos = null;
        if (special) {
            int start = random.nextInt(4);
            for (int i = 0; i < 4 && cauldronPos == null; i++) {
                BlockPos candidate = pos.relative(Direction.from2DDataValue((start + i) % 4));
                if (isFreeSpot(level, candidate)) {
                    cauldronPos = candidate;
                }
            }
            if (cauldronPos == null) {
                special = false;
            }
        }

        BlockState chest = ModRegistry.RAINBOW_CHEST.get().defaultBlockState()
                .setValue(RainbowChestBlock.FACING, facing)
                .setValue(RainbowChestBlock.SPARKLING, true);
        level.setBlock(pos, chest, 3);
        BlockEntity entity = level.getBlockEntity(pos);
        if (entity instanceof RainbowChestBlockEntity chestEntity) {
            chestEntity.setLootTable(special ? ModRegistry.LEPRECHAUN_LOOT : ModRegistry.TREASURE_LOOT, random.nextLong());
            chestEntity.setModLoot(special);
        }

        RainbowEntity rainbow = ModRegistry.RAINBOW.get().create(level);
        if (rainbow == null) {
            level.removeBlock(pos, false);
            return false;
        }
        rainbow.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, yaw, 0.0F);
        rainbow.setRadius(26 + random.nextInt(14));
        rainbow.setIgnoreDay(ignoreDay);
        level.addFreshEntity(rainbow);

        if (special && cauldronPos != null) {
            level.setBlock(cauldronPos, ModRegistry.GOLD_CAULDRON.get().defaultBlockState(), 3);
            spawnLeprechaunNear(level, pos, cauldronPos);
        }

        level.sendParticles(ParticleTypes.END_ROD, pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D,
                30, 0.5D, 0.8D, 0.5D, 0.05D);
        return true;
    }

    /** Coloca a San Patricio junto al cofre y el caldero. */
    private static void spawnLeprechaunNear(ServerLevel level, BlockPos chestPos, BlockPos cauldronPos) {
        BlockPos spot = null;
        search:
        for (int i = 0; i < 4; i++) {
            Direction d = Direction.from2DDataValue(i);
            BlockPos[] candidates = {chestPos.relative(d), chestPos.relative(d).relative(d.getClockWise())};
            for (BlockPos candidate : candidates) {
                if (!candidate.equals(cauldronPos) && !candidate.equals(chestPos) && isFreeSpot(level, candidate)) {
                    spot = candidate;
                    break search;
                }
            }
        }
        if (spot == null) {
            spot = chestPos.above();
        }
        LeprechaunEntity leprechaun = ModRegistry.LEPRECHAUN.get().create(level);
        if (leprechaun == null) {
            return;
        }
        leprechaun.moveTo(spot.getX() + 0.5D, spot.getY(), spot.getZ() + 0.5D, level.random.nextFloat() * 360.0F, 0.0F);
        leprechaun.setDespawnDelay(LEPRECHAUN_STAY);
        leprechaun.restrictTo(cauldronPos, 10);
        level.addFreshEntity(leprechaun);
        level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, spot.getX() + 0.5D, spot.getY() + 1.0D, spot.getZ() + 0.5D,
                20, 0.3D, 0.6D, 0.3D, 0.2D);
    }

    /** Durante el Día de San Patricio un duende puede pasear cerca de un jugador (se va a los 5 minutos). */
    public static boolean spawnWanderingLeprechaun(ServerLevel level, ServerPlayer player) {
        RandomSource random = level.random;
        BlockPos origin = player.blockPosition();
        for (int attempt = 0; attempt < 10; attempt++) {
            double angle = random.nextDouble() * Math.PI * 2.0D;
            double distance = 18.0D + random.nextInt(20);
            int x = origin.getX() + (int) Math.round(Math.cos(angle) * distance);
            int z = origin.getZ() + (int) Math.round(Math.sin(angle) * distance);
            if (!level.hasChunk(x >> 4, z >> 4)) {
                continue;
            }
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos pos = new BlockPos(x, y, z);
            if (!isFreeSpot(level, pos)) {
                continue;
            }
            LeprechaunEntity leprechaun = ModRegistry.LEPRECHAUN.get().create(level);
            if (leprechaun == null) {
                return false;
            }
            leprechaun.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, random.nextFloat() * 360.0F, 0.0F);
            leprechaun.setDespawnDelay(WANDERING_STAY);
            level.addFreshEntity(leprechaun);
            level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D,
                    20, 0.3D, 0.6D, 0.3D, 0.2D);
            player.displayClientMessage(Component.translatable("message.treasure_rainbow.leprechaun_nearby"), true);
            return true;
        }
        return false;
    }

    /** Alguien ha abierto el cofre por primera vez: celebración y el cofre deja de brillar. */
    public static void onTreasureClaimed(ServerLevel level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        if (state.getBlock() instanceof RainbowChestBlock && state.getValue(RainbowChestBlock.SPARKLING)) {
            level.setBlock(pos, state.setValue(RainbowChestBlock.SPARKLING, false), 3);
        }
        Vec3 c = Vec3.atCenterOf(pos).add(0.0D, 0.8D, 0.0D);
        level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, c.x, c.y, c.z, 60, 0.4D, 0.5D, 0.4D, 0.4D);
        level.sendParticles(ParticleTypes.FIREWORK, c.x, c.y, c.z, 30, 0.3D, 0.4D, 0.3D, 0.2D);
        level.playSound(null, pos, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.BLOCKS, 1.0F, 1.0F);
        level.playSound(null, pos, SoundEvents.FIREWORK_ROCKET_TWINKLE, SoundSource.BLOCKS, 1.2F, 1.0F);
    }

    public static void announce(ServerPlayer player, boolean special) {
        player.displayClientMessage(Component.translatable(special
                ? "message.treasure_rainbow.appeared_special" : "message.treasure_rainbow.appeared"), true);
    }
}
