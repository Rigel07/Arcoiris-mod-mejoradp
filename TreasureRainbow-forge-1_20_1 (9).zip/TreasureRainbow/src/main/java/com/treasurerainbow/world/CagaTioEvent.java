package com.treasurerainbow.world;

import com.treasurerainbow.ModRegistry;
import com.treasurerainbow.TreasureRainbowMod;
import com.treasurerainbow.entity.CagaTioEntity;
import com.treasurerainbow.item.BarretinaItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.time.LocalDate;

/**
 * El día del Caga Tió (tradición navideña catalana). Empieza al amanecer (probabilidad pequeña; más alta del
 * 8 al 25 de diciembre reales y segura el 24 y 25) y dura hasta el siguiente amanecer. Aparecen Tiós a los
 * que se da de comer y se pega con un palo para que cagen regalos. Con la Barretina puesta tienes Suerte (siempre).
 */
@Mod.EventBusSubscriber(modid = TreasureRainbowMod.MOD_ID)
public final class CagaTioEvent {
    private CagaTioEvent() {}

    public static final double START_CHANCE = 0.06D;

    public static boolean isActive(MinecraftServer server) {
        return server != null && CagaTioData.get(server.overworld()).active;
    }

    public static boolean isActive(ServerLevel level) {
        return isActive(level.getServer());
    }

    public static boolean start(MinecraftServer server) {
        CagaTioData data = CagaTioData.get(server.overworld());
        if (data.active) {
            return false;
        }
        data.active = true;
        data.setDirty();
        Component title = Component.translatable("message.treasure_rainbow.cagatio_start.title");
        Component subtitle = Component.translatable("message.treasure_rainbow.cagatio_start.subtitle");
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.connection.send(new ClientboundSetTitlesAnimationPacket(10, 80, 30));
            player.connection.send(new ClientboundSetSubtitleTextPacket(subtitle));
            player.connection.send(new ClientboundSetTitleTextPacket(title));
            player.playNotifySound(SoundEvents.WOOD_HIT, SoundSource.PLAYERS, 1.0F, 0.8F);
            if (player.level() instanceof ServerLevel level && level.dimension() == Level.OVERWORLD) {
                for (int i = 0; i < 2; i++) {
                    spawnTio(level, player);
                }
            }
        }
        server.getPlayerList().broadcastSystemMessage(Component.translatable("message.treasure_rainbow.cagatio_start.chat"), false);
        return true;
    }

    public static boolean stop(MinecraftServer server) {
        CagaTioData data = CagaTioData.get(server.overworld());
        if (!data.active) {
            return false;
        }
        data.active = false;
        data.setDirty();
        server.getPlayerList().broadcastSystemMessage(Component.translatable("message.treasure_rainbow.cagatio_end"), false);
        return true;
    }

    private static double startChance() {
        LocalDate today = LocalDate.now();
        if (today.getMonthValue() == 12) {
            int d = today.getDayOfMonth();
            if (d == 24 || d == 25) {
                return 1.0D;
            }
            if (d >= 8 && d < 24) {
                return 0.25D;
            }
        }
        return START_CHANCE;
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null || server.getTickCount() % 20 != 0) {
            return;
        }
        ServerLevel overworld = server.overworld();
        CagaTioData data = CagaTioData.get(overworld);
        long day = overworld.getDayTime() / 24000L;
        if (data.lastDay < 0L) {
            data.lastDay = day;
            data.setDirty();
        } else if (day != data.lastDay) {
            data.lastDay = day;
            data.setDirty();
            if (data.active) {
                stop(server);
            } else if (overworld.random.nextDouble() < startChance()) {
                start(server);
            }
        }
        // Barretina: Suerte mientras la llevas (siempre).
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (!player.isSpectator() && BarretinaItem.isWearing(player)) {
                MobEffectInstance current = player.getEffect(MobEffects.LUCK);
                if (current == null || current.getDuration() < 100) {
                    player.addEffect(new MobEffectInstance(MobEffects.LUCK, 240, 0, false, false, false));
                }
            }
        }
        if (!data.active) {
            return;
        }
        for (ServerPlayer player : overworld.players()) {
            if (!player.isSpectator()
                    && overworld.getEntitiesOfClass(CagaTioEntity.class, player.getBoundingBox().inflate(48.0D)).size() < 3
                    && overworld.random.nextDouble() < 0.15D) {
                spawnTio(overworld, player);
            }
        }
    }

    public static boolean spawnTio(ServerLevel level, ServerPlayer player) {
        BlockPos origin = player.blockPosition();
        for (int attempt = 0; attempt < 10; attempt++) {
            double angle = level.random.nextDouble() * Math.PI * 2.0D;
            double distance = 8.0D + level.random.nextInt(16);
            int x = origin.getX() + (int) Math.round(Math.cos(angle) * distance);
            int z = origin.getZ() + (int) Math.round(Math.sin(angle) * distance);
            if (!level.hasChunk(x >> 4, z >> 4)) {
                continue;
            }
            BlockPos pos = new BlockPos(x, level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z), z);
            if (!RainbowSpawner.isFreeSpot(level, pos)) {
                continue;
            }
            CagaTioEntity tio = ModRegistry.CAGA_TIO.get().create(level);
            if (tio == null) {
                return false;
            }
            tio.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, level.random.nextFloat() * 360.0F, 0.0F);
            tio.setEventBound(true);
            level.addFreshEntity(tio);
            level.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5D, pos.getY() + 0.8D, pos.getZ() + 0.5D, 15, 0.3D, 0.4D, 0.3D, 0.05D);
            return true;
        }
        return false;
    }
}
