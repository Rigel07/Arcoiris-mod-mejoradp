package com.treasurerainbow.world;

import com.treasurerainbow.ModRegistry;
import com.treasurerainbow.TreasureRainbowMod;
import com.treasurerainbow.entity.CupidEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.time.LocalDate;

/**
 * San Valentín: empieza al amanecer (probabilidad pequeña; segura el 14 de febrero real) y dura hasta el
 * siguiente amanecer. Aparece Cupido, que lanza flechas de corazón que curan y puede soltar el Halo Angelical.
 */
@Mod.EventBusSubscriber(modid = TreasureRainbowMod.MOD_ID)
public final class ValentineEvent {
    private ValentineEvent() {}

    public static final double START_CHANCE = 0.08D;

    public static boolean isActive(MinecraftServer server) {
        return server != null && ValentineData.get(server.overworld()).active;
    }

    public static boolean isActive(ServerLevel level) {
        return isActive(level.getServer());
    }

    public static boolean start(MinecraftServer server) {
        ValentineData data = ValentineData.get(server.overworld());
        if (data.active) {
            return false;
        }
        data.active = true;
        data.setDirty();
        Component title = Component.translatable("message.treasure_rainbow.valentine_start.title");
        Component subtitle = Component.translatable("message.treasure_rainbow.valentine_start.subtitle");
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.connection.send(new ClientboundSetTitlesAnimationPacket(10, 80, 30));
            player.connection.send(new ClientboundSetSubtitleTextPacket(subtitle));
            player.connection.send(new ClientboundSetTitleTextPacket(title));
            player.playNotifySound(SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.2F);
            if (player.level() instanceof ServerLevel level && level.dimension() == Level.OVERWORLD) {
                spawnCupid(level, player);
            }
        }
        server.getPlayerList().broadcastSystemMessage(Component.translatable("message.treasure_rainbow.valentine_start.chat"), false);
        return true;
    }

    public static boolean stop(MinecraftServer server) {
        ValentineData data = ValentineData.get(server.overworld());
        if (!data.active) {
            return false;
        }
        data.active = false;
        data.setDirty();
        server.getPlayerList().broadcastSystemMessage(Component.translatable("message.treasure_rainbow.valentine_end"), false);
        return true;
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null || server.getTickCount() % 20 != 0) {
            return;
        }
        ServerLevel overworld = server.overworld();
        ValentineData data = ValentineData.get(overworld);
        long day = overworld.getDayTime() / 24000L;
        if (data.lastDay < 0L) {
            data.lastDay = day;
            data.setDirty();
        } else if (day != data.lastDay) {
            data.lastDay = day;
            data.setDirty();
            if (data.active) {
                stop(server);
            } else if (overworld.random.nextDouble() < startChance()) {
                start(server);
            }
        }
        if (!data.active) {
            return;
        }
        for (ServerPlayer player : overworld.players()) {
            if (player.isSpectator()) {
                continue;
            }
            overworld.sendParticles(ParticleTypes.HEART, player.getX(), player.getY() + 2.5D, player.getZ(), 3, 5.0D, 2.0D, 5.0D, 0.02D);
            if (overworld.getEntitiesOfClass(CupidEntity.class, player.getBoundingBox().inflate(64.0D)).size() < 2
                    && overworld.random.nextDouble() < 0.2D) {
                spawnCupid(overworld, player);
            }
        }
    }

    private static double startChance() {
        LocalDate today = LocalDate.now();
        return today.getMonthValue() == 2 && today.getDayOfMonth() == 14 ? 1.0D : START_CHANCE;
    }

    public static boolean spawnCupid(ServerLevel level, ServerPlayer player) {
        BlockPos origin = player.blockPosition();
        double angle = level.random.nextDouble() * Math.PI * 2.0D;
        double distance = 12.0D + level.random.nextInt(14);
        double x = origin.getX() + Math.cos(angle) * distance;
        double z = origin.getZ() + Math.sin(angle) * distance;
        if (!level.hasChunk(((int) Math.floor(x)) >> 4, ((int) Math.floor(z)) >> 4)) {
            return false;
        }
        CupidEntity cupid = ModRegistry.CUPID.get().create(level);
        if (cupid == null) {
            return false;
        }
        cupid.moveTo(x, player.getY() + 3.0D, z, level.random.nextFloat() * 360.0F, 0.0F);
        if (!level.noCollision(cupid)) {
            cupid.moveTo(x, player.getY() + 6.0D, z);
            if (!level.noCollision(cupid)) {
                return false;
            }
        }
        cupid.setEventBound(true);
        level.addFreshEntity(cupid);
        level.sendParticles(ParticleTypes.HEART, x, cupid.getY() + 0.5D, z, 20, 0.4D, 0.5D, 0.4D, 0.05D);
        return true;
    }
}
