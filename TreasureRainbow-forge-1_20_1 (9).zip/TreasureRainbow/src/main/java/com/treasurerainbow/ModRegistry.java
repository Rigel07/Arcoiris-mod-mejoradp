package com.treasurerainbow;

import com.treasurerainbow.block.FourLeafCloverBlock;
import com.treasurerainbow.block.GoldCauldronBlock;
import com.treasurerainbow.block.RainbowChestBlock;
import com.treasurerainbow.block.RainbowChestBlockEntity;
import com.treasurerainbow.block.SanJuanBonfireBlock;
import com.treasurerainbow.block.GiftBlock;
import com.treasurerainbow.block.LongshipBlock;
import com.treasurerainbow.block.MagicSnowBlock;
import com.treasurerainbow.effect.ChristmasSpiritEffect;
import com.treasurerainbow.effect.SaintPatrickEffect;
import com.treasurerainbow.effect.SolsticeBlessingEffect;
import com.treasurerainbow.entity.BusoEntity;
import com.treasurerainbow.entity.CagaTioEntity;
import com.treasurerainbow.entity.CrazyBirdEntity;
import com.treasurerainbow.entity.CupidEntity;
import com.treasurerainbow.entity.ElfEntity;
import com.treasurerainbow.entity.GuizerEntity;
import com.treasurerainbow.entity.HeartArrowEntity;
import com.treasurerainbow.entity.LeprechaunEntity;
import com.treasurerainbow.entity.SleighEntity;
import com.treasurerainbow.entity.RainbowEntity;
import com.treasurerainbow.item.AngelHaloItem;
import com.treasurerainbow.item.BarretinaItem;
import com.treasurerainbow.item.BusoMaskItem;
import com.treasurerainbow.item.GuizerHelmetItem;
import com.treasurerainbow.item.MeadItem;
import com.treasurerainbow.item.RainbowGemItem;
import com.treasurerainbow.item.SanJuanWaterItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModRegistry {
    private ModRegistry() {}

    private static final String ID = TreasureRainbowMod.MOD_ID;

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, ID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ID);
    public static final DeferredRegister<MobEffect> EFFECTS = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ID);

    /** Botín del cofre del arcoíris (data/treasure_rainbow/loot_tables/chests/rainbow_treasure.json). */
    public static final ResourceLocation TREASURE_LOOT = new ResourceLocation(ID, "chests/rainbow_treasure");
    /** Botín legendario del duende (data/treasure_rainbow/loot_tables/chests/leprechaun_treasure.json). */
    public static final ResourceLocation LEPRECHAUN_LOOT = new ResourceLocation(ID, "chests/leprechaun_treasure");

    // ---- Bloques ----
    public static final RegistryObject<Block> RAINBOW_CHEST = BLOCKS.register("rainbow_chest",
            () -> new RainbowChestBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.GOLD)
                    .strength(2.5F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()
                    .lightLevel(state -> state.getValue(RainbowChestBlock.SPARKLING) ? 7 : 0)));

    public static final RegistryObject<Block> RAINBOW_WOOL = BLOCKS.register("rainbow_wool",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PINK)
                    .strength(0.8F)
                    .sound(SoundType.WOOL)));

    public static final RegistryObject<Block> FOUR_LEAF_CLOVER = BLOCKS.register("four_leaf_clover",
            () -> new FourLeafCloverBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.PLANT)
                    .noCollission()
                    .instabreak()
                    .sound(SoundType.GRASS)
                    .pushReaction(PushReaction.DESTROY)));

    public static final RegistryObject<Block> GOLD_CAULDRON = BLOCKS.register("gold_cauldron",
            () -> new GoldCauldronBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.GOLD)
                    .strength(3.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()
                    .lightLevel(state -> 8)));

    public static final RegistryObject<Block> ST_JOHNS_WORT = BLOCKS.register("st_johns_wort",
            () -> new FourLeafCloverBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.PLANT)
                    .noCollission()
                    .instabreak()
                    .sound(SoundType.GRASS)
                    .pushReaction(PushReaction.DESTROY)));

    public static final RegistryObject<Block> SAN_JUAN_BONFIRE = BLOCKS.register("san_juan_bonfire",
            () -> new SanJuanBonfireBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.PODZOL)
                    .strength(0.5F)
                    .sound(SoundType.WOOD)
                    .noCollission()
                    .lightLevel(state -> 15)));

    public static final RegistryObject<Block> GIFT = BLOCKS.register("gift",
            () -> new GiftBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_RED)
                    .strength(0.5F)
                    .sound(SoundType.WOOL)
                    .noOcclusion()
                    .lightLevel(state -> 5)));

    public static final RegistryObject<Block> MAGIC_SNOW = BLOCKS.register("magic_snow",
            () -> new MagicSnowBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.SNOW)
                    .replaceable()
                    .forceSolidOff()
                    .strength(0.1F)
                    .sound(SoundType.SNOW)
                    .pushReaction(PushReaction.DESTROY)));

    public static final RegistryObject<Block> VIKING_LONGSHIP = BLOCKS.register("viking_longship",
            () -> new LongshipBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.WOOD)
                    .strength(2.0F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()));

    public static final RegistryObject<BlockEntityType<RainbowChestBlockEntity>> RAINBOW_CHEST_BE = BLOCK_ENTITIES.register(
            "rainbow_chest",
            () -> BlockEntityType.Builder.of(RainbowChestBlockEntity::new, RAINBOW_CHEST.get()).build(null));

    // ---- Entidades ----
    public static final RegistryObject<EntityType<RainbowEntity>> RAINBOW = ENTITIES.register("rainbow",
            () -> EntityType.Builder.<RainbowEntity>of(RainbowEntity::new, MobCategory.MISC)
                    .sized(0.5F, 0.5F)
                    .clientTrackingRange(16)
                    .updateInterval(20)
                    .fireImmune()
                    .build(ID + ":rainbow"));

    public static final RegistryObject<EntityType<LeprechaunEntity>> LEPRECHAUN = ENTITIES.register("leprechaun",
            () -> EntityType.Builder.<LeprechaunEntity>of(LeprechaunEntity::new, MobCategory.CREATURE)
                    .sized(0.5F, 1.4F)
                    .clientTrackingRange(10)
                    .build(ID + ":leprechaun"));

    public static final RegistryObject<EntityType<CrazyBirdEntity>> CRAZY_BIRD = ENTITIES.register("pajaro_loco",
            () -> EntityType.Builder.<CrazyBirdEntity>of(CrazyBirdEntity::new, MobCategory.CREATURE)
                    .sized(1.4F, 2.6F)
                    .clientTrackingRange(10)
                    .build(ID + ":pajaro_loco"));

    public static final RegistryObject<EntityType<ElfEntity>> ELF = ENTITIES.register("elf",
            () -> EntityType.Builder.<ElfEntity>of(ElfEntity::new, MobCategory.CREATURE)
                    .sized(0.5F, 1.3F)
                    .clientTrackingRange(10)
                    .build(ID + ":elf"));

    public static final RegistryObject<EntityType<SleighEntity>> SLEIGH = ENTITIES.register("sleigh",
            () -> EntityType.Builder.<SleighEntity>of(SleighEntity::new, MobCategory.MISC)
                    .sized(3.0F, 2.0F)
                    .clientTrackingRange(16)
                    .updateInterval(1)
                    .fireImmune()
                    .build(ID + ":sleigh"));

    public static final RegistryObject<EntityType<CupidEntity>> CUPID = ENTITIES.register("cupid",
            () -> EntityType.Builder.<CupidEntity>of(CupidEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 0.9F)
                    .clientTrackingRange(10)
                    .build(ID + ":cupid"));

    public static final RegistryObject<EntityType<HeartArrowEntity>> HEART_ARROW = ENTITIES.register("heart_arrow",
            () -> EntityType.Builder.<HeartArrowEntity>of(HeartArrowEntity::new, MobCategory.MISC)
                    .sized(0.5F, 0.5F)
                    .clientTrackingRange(4)
                    .updateInterval(20)
                    .build(ID + ":heart_arrow"));

    public static final RegistryObject<EntityType<BusoEntity>> BUSO = ENTITIES.register("buso",
            () -> EntityType.Builder.<BusoEntity>of(BusoEntity::new, MobCategory.CREATURE)
                    .sized(0.7F, 1.9F)
                    .clientTrackingRange(10)
                    .build(ID + ":buso"));

    public static final RegistryObject<EntityType<GuizerEntity>> GUIZER = ENTITIES.register("guizer",
            () -> EntityType.Builder.<GuizerEntity>of(GuizerEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.8F)
                    .clientTrackingRange(10)
                    .build(ID + ":guizer"));

    public static final RegistryObject<EntityType<CagaTioEntity>> CAGA_TIO = ENTITIES.register("caga_tio",
            () -> EntityType.Builder.<CagaTioEntity>of(CagaTioEntity::new, MobCategory.CREATURE)
                    .sized(0.9F, 1.1F)
                    .clientTrackingRange(10)
                    .build(ID + ":caga_tio"));

    // ---- Efectos ----
    public static final RegistryObject<MobEffect> SAINT_PATRICK = EFFECTS.register("saint_patrick", SaintPatrickEffect::new);

    public static final RegistryObject<MobEffect> SOLSTICE_BLESSING = EFFECTS.register("solstice_blessing", SolsticeBlessingEffect::new);

    public static final RegistryObject<MobEffect> CHRISTMAS_SPIRIT = EFFECTS.register("christmas_spirit", ChristmasSpiritEffect::new);

    // ---- Objetos ----
    public static final RegistryObject<Item> RAINBOW_GEM = ITEMS.register("rainbow_gem",
            () -> new RainbowGemItem(new Item.Properties().rarity(Rarity.EPIC).stacksTo(16)));
    public static final RegistryObject<Item> RAINBOW_DUST = ITEMS.register("rainbow_dust",
            () -> new Item(new Item.Properties().rarity(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> RAINBOW_CHEST_ITEM = ITEMS.register("rainbow_chest",
            () -> new BlockItem(RAINBOW_CHEST.get(), new Item.Properties().rarity(Rarity.RARE)));
    public static final RegistryObject<Item> RAINBOW_WOOL_ITEM = ITEMS.register("rainbow_wool",
            () -> new BlockItem(RAINBOW_WOOL.get(), new Item.Properties()));
    public static final RegistryObject<Item> FOUR_LEAF_CLOVER_ITEM = ITEMS.register("four_leaf_clover",
            () -> new BlockItem(FOUR_LEAF_CLOVER.get(), new Item.Properties().rarity(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> GOLD_CAULDRON_ITEM = ITEMS.register("gold_cauldron",
            () -> new BlockItem(GOLD_CAULDRON.get(), new Item.Properties().rarity(Rarity.RARE)));
    public static final RegistryObject<Item> ST_JOHNS_WORT_ITEM = ITEMS.register("st_johns_wort",
            () -> new BlockItem(ST_JOHNS_WORT.get(), new Item.Properties()));
    public static final RegistryObject<Item> SAN_JUAN_BONFIRE_ITEM = ITEMS.register("san_juan_bonfire",
            () -> new BlockItem(SAN_JUAN_BONFIRE.get(), new Item.Properties().rarity(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> COCA_DE_SAN_JUAN = ITEMS.register("coca_de_san_juan",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(10).saturationMod(1.0F).build())));
    public static final RegistryObject<Item> SAN_JUAN_WATER = ITEMS.register("san_juan_water",
            () -> new SanJuanWaterItem(new Item.Properties().rarity(Rarity.UNCOMMON).stacksTo(16)));
    public static final RegistryObject<Item> GIFT_ITEM = ITEMS.register("gift",
            () -> new BlockItem(GIFT.get(), new Item.Properties().rarity(Rarity.RARE)));
    public static final RegistryObject<Item> ANGEL_HALO = ITEMS.register("angel_halo",
            () -> new AngelHaloItem(new Item.Properties().rarity(Rarity.EPIC).stacksTo(1)));
    public static final RegistryObject<Item> CRAZY_BIRD_SPAWN_EGG = ITEMS.register("crazy_bird_spawn_egg",
            () -> new ForgeSpawnEggItem(CRAZY_BIRD, 0xE0C890, 0xA03020, new Item.Properties()));
    public static final RegistryObject<Item> ELF_SPAWN_EGG = ITEMS.register("elf_spawn_egg",
            () -> new ForgeSpawnEggItem(ELF, 0x1E8C3C, 0xC8242E, new Item.Properties()));
    public static final RegistryObject<Item> CUPID_SPAWN_EGG = ITEMS.register("cupid_spawn_egg",
            () -> new ForgeSpawnEggItem(CUPID, 0xFFB6C1, 0xFFFFFF, new Item.Properties()));
    public static final RegistryObject<Item> BUSHO_MASK = ITEMS.register("busho_mask",
            () -> new BusoMaskItem(new Item.Properties().rarity(Rarity.RARE).stacksTo(1)));
    public static final RegistryObject<Item> FARSANGI_FANK = ITEMS.register("farsangi_fank",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(6).saturationMod(0.7F).build())));
    public static final RegistryObject<Item> BUSO_SPAWN_EGG = ITEMS.register("buso_spawn_egg",
            () -> new ForgeSpawnEggItem(BUSO, 0xF2EEDD, 0x6B4423, new Item.Properties()));
    public static final RegistryObject<Item> VIKING_LONGSHIP_ITEM = ITEMS.register("viking_longship",
            () -> new BlockItem(VIKING_LONGSHIP.get(), new Item.Properties().rarity(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> GUIZER_HELMET = ITEMS.register("guizer_helmet",
            () -> new GuizerHelmetItem(new Item.Properties().rarity(Rarity.RARE).stacksTo(1)));
    public static final RegistryObject<Item> MEAD = ITEMS.register("mead",
            () -> new MeadItem(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> GUIZER_SPAWN_EGG = ITEMS.register("guizer_spawn_egg",
            () -> new ForgeSpawnEggItem(GUIZER, 0x2A4886, 0xC45F24, new Item.Properties()));
    public static final RegistryObject<Item> BARRETINA = ITEMS.register("barretina",
            () -> new BarretinaItem(new Item.Properties().rarity(Rarity.RARE).stacksTo(1)));
    public static final RegistryObject<Item> TORRO = ITEMS.register("torro",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(4).saturationMod(0.6F).build())));
    public static final RegistryObject<Item> CAGA_TIO_SPAWN_EGG = ITEMS.register("caga_tio_spawn_egg",
            () -> new ForgeSpawnEggItem(CAGA_TIO, 0x68441F, 0xC81E28, new Item.Properties()));
    public static final RegistryObject<Item> LEPRECHAUN_SPAWN_EGG = ITEMS.register("leprechaun_spawn_egg",
            () -> new ForgeSpawnEggItem(LEPRECHAUN, 0x1E9E3E, 0xFFD028, new Item.Properties()));

    // ---- Pestaña creativa ----
    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("treasure_rainbow_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.treasure_rainbow"))
                    .icon(() -> new ItemStack(RAINBOW_GEM.get()))
                    .displayItems((params, output) -> {
                        output.accept(RAINBOW_GEM.get());
                        output.accept(RAINBOW_DUST.get());
                        output.accept(RAINBOW_CHEST_ITEM.get());
                        output.accept(RAINBOW_WOOL_ITEM.get());
                        output.accept(FOUR_LEAF_CLOVER_ITEM.get());
                        output.accept(GOLD_CAULDRON_ITEM.get());
                        output.accept(LEPRECHAUN_SPAWN_EGG.get());
                        output.accept(ST_JOHNS_WORT_ITEM.get());
                        output.accept(SAN_JUAN_BONFIRE_ITEM.get());
                        output.accept(COCA_DE_SAN_JUAN.get());
                        output.accept(SAN_JUAN_WATER.get());
                        output.accept(GIFT_ITEM.get());
                        output.accept(ANGEL_HALO.get());
                        output.accept(CRAZY_BIRD_SPAWN_EGG.get());
                        output.accept(ELF_SPAWN_EGG.get());
                        output.accept(CUPID_SPAWN_EGG.get());
                        output.accept(BUSHO_MASK.get());
                        output.accept(FARSANGI_FANK.get());
                        output.accept(BUSO_SPAWN_EGG.get());
                        output.accept(VIKING_LONGSHIP_ITEM.get());
                        output.accept(GUIZER_HELMET.get());
                        output.accept(MEAD.get());
                        output.accept(GUIZER_SPAWN_EGG.get());
                        output.accept(BARRETINA.get());
                        output.accept(TORRO.get());
                        output.accept(CAGA_TIO_SPAWN_EGG.get());
                    })
                    .build());

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
        BLOCK_ENTITIES.register(bus);
        ENTITIES.register(bus);
        EFFECTS.register(bus);
        TABS.register(bus);
    }
}
